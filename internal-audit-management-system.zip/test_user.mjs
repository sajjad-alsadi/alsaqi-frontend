import { db, initDb } from './src/server/db/index.js';

async function test() {
  await initDb();
  let user = await db.prepare("SELECT username FROM users LIMIT 1;").get();
  console.log(user);
}
test();
