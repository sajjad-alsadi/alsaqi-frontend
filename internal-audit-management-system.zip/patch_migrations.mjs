import fs from 'fs';
let content = fs.readFileSync('src/server/db/migrations.ts', 'utf8');

const oldAuditTasks = `    \`CREATE TABLE IF NOT EXISTS audit_tasks (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      audit_id UUID,
      procedure TEXT NOT NULL,
      responsible TEXT NOT NULL,
      status TEXT DEFAULT 'Open',
      evidence_link TEXT,
      evidence_id UUID,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(audit_id) REFERENCES audit_plans(id)
    )\`,`;

const newAuditTasks = `    \`CREATE TABLE IF NOT EXISTS audit_tasks (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      task_number VARCHAR(30) UNIQUE NOT NULL,
      title TEXT NOT NULL,
      plan_id UUID NOT NULL REFERENCES audit_plans(id),
      program_id UUID REFERENCES audit_programs(id),
      audit_type TEXT NOT NULL, 
      status TEXT NOT NULL DEFAULT 'draft',
      assigned_to UUID REFERENCES users(id),
      audited_unit_id UUID REFERENCES org_entities(id),
      planned_hours INTEGER,
      actual_hours INTEGER DEFAULT 0,
      period_from DATE,
      period_to DATE,
      due_date DATE,
      approved_by UUID REFERENCES users(id),
      approved_at TIMESTAMPTZ,
      created_by UUID REFERENCES users(id),
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      deleted_at TIMESTAMPTZ
    )\`,
    \`CREATE TABLE IF NOT EXISTS finding_risks (
      finding_id UUID NOT NULL REFERENCES audit_findings(id),
      risk_id UUID NOT NULL REFERENCES risk_register(id),
      PRIMARY KEY (finding_id, risk_id)
    )\`,
    \`CREATE TABLE IF NOT EXISTS finding_compliance (
      finding_id UUID NOT NULL REFERENCES audit_findings(id),
      compliance_id UUID NOT NULL REFERENCES central_bank_instructions(id),
      PRIMARY KEY (finding_id, compliance_id)
    )\`,
    \`CREATE TABLE IF NOT EXISTS compliance_items (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      ref_number TEXT NOT NULL,
      title TEXT NOT NULL,
      type TEXT NOT NULL,
      issuing_authority TEXT,
      issue_date DATE,
      effective_date DATE,
      compliance_status TEXT DEFAULT 'under_review',
      responsible_person_id UUID REFERENCES users(id),
      attachment_path TEXT,
      notes TEXT,
      created_by UUID REFERENCES users(id),
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
    )\`,`;

content = content.replace(oldAuditTasks, newAuditTasks);

const findingsCols = [
  { name: "finding_number", type: "VARCHAR(50) UNIQUE" },
  { name: "finding_type", type: "TEXT" },
  { name: "impact", type: "TEXT" },
  { name: "root_cause", type: "TEXT" },
  { name: "responsible_unit_id", type: "UUID REFERENCES org_entities(id)" },
  { name: "risk_id", type: "UUID REFERENCES risk_register(id)" },
  { name: "created_by", type: "UUID REFERENCES users(id)" },
  { name: "deleted_at", type: "TIMESTAMPTZ" }
];
const recCols = [
  { name: "rec_number", type: "VARCHAR(70) UNIQUE" },
  { name: "action_plan", type: "TEXT" },
  { name: "responsible_person_id", type: "UUID REFERENCES users(id)" },
  { name: "priority", type: "TEXT DEFAULT 'medium'" },
  { name: "follow_up_date", type: "DATE" },
  { name: "closure_evidence_path", type: "TEXT" },
  { name: "closed_by", type: "UUID REFERENCES users(id)" },
  { name: "closed_at", type: "TIMESTAMPTZ" },
  { name: "created_by", type: "UUID REFERENCES users(id)" }
];
const riskCols = [
  { name: "likelihood_num", type: "INTEGER CHECK(likelihood_num BETWEEN 1 AND 5)" },
  { name: "impact_num", type: "INTEGER CHECK(impact_num BETWEEN 1 AND 5)" },
  { name: "risk_score_calc", type: "INTEGER" },
  { name: "risk_level_calc", type: "TEXT" }
];

let migrationsToAdd = "";

for (const c of findingsCols) {
  migrationsToAdd += `\n    { table: "audit_findings", column: "${c.name}", type: "${c.type}" },`;
}
for (const c of recCols) {
  migrationsToAdd += `\n    { table: "recommendations", column: "${c.name}", type: "${c.type}" },`;
}
for (const c of riskCols) {
  migrationsToAdd += `\n    { table: "risk_register", column: "${c.name}", type: "${c.type}" },`;
}

content = content.replace('const migrations = [', `const migrations = [${migrationsToAdd}`);

fs.writeFileSync('src/server/db/migrations.ts', content);
