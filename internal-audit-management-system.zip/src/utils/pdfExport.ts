import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import api from '../services/api';

export const fetchPdfSettings = async (token: string) => {
  try {
    const res = await api.get('/pdf-settings', {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (res.data) {
      return res.data;
    }
  } catch (err) {
    console.error('Error fetching PDF settings:', err);
  }
  return null;
};

export interface PdfSection {
  type: 'text' | 'table';
  title?: string;
  content?: string;
  columns?: any[];
  data?: any[];
}

// Cache the font so we don't download it every time
let cachedArabicFont: string | null = null;

export const generatePdf = async (
  title: string, 
  sections: PdfSection[],
  token: string,
  language: 'ar' | 'en'
) => {
  const settings = await fetchPdfSettings(token) || {
    arabic_font_name: 'Cairo',
    arabic_font_size: 12,
    heading_font_size: 16,
    subheading_font_size: 14,
    table_font_size: 10,
    rtl_enabled: language === 'ar' ? 1 : 0,
    margin_top: 40,
    margin_right: 40,
    margin_bottom: 40,
    margin_left: 40,
    header_template: '',
    footer_template: '',
    logo_position: 'right',
    show_page_number: 1
  };

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4'
  });

  const isRTL = settings.rtl_enabled === 1 || language === 'ar';
  
  if (isRTL) {
    try {
      if (!cachedArabicFont) {
        // Try multiple reliable sources for Arabic TTF fonts
        const fontUrls = [
          'https://raw.githubusercontent.com/google/fonts/main/ofl/amiri/Amiri-Regular.ttf',
          'https://raw.githubusercontent.com/google/fonts/main/ofl/tajawal/Tajawal-Regular.ttf',
          'https://raw.githubusercontent.com/google/fonts/main/ofl/cairo/static/Cairo-Regular.ttf'
        ];
        
        let buffer: ArrayBuffer | null = null;
        let fontName = 'Amiri';
        let fileName = 'Amiri-Regular.ttf';
        
        for (const url of fontUrls) {
          try {
            const response = await fetch(url);
            if (response.ok) {
              const contentType = response.headers.get('content-type');
              // Ensure we don't accidentally parse an HTML 404 page
              if (contentType && contentType.includes('text/html')) {
                continue;
              }
              buffer = await response.arrayBuffer();
              if (url.includes('Tajawal')) {
                fontName = 'Tajawal';
                fileName = 'Tajawal-Regular.ttf';
              } else if (url.includes('Cairo')) {
                fontName = 'Cairo';
                fileName = 'Cairo-Regular.ttf';
              }
              break;
            }
          } catch (err) {
            console.warn(`Failed to fetch font from ${url}`, err);
          }
        }
        
        if (!buffer) {
          throw new Error('Failed to fetch any Arabic font');
        }
        
        // Efficiently convert ArrayBuffer to Base64
        const bytes = new Uint8Array(buffer);
        let binary = '';
        const chunkSize = 8192;
        for (let i = 0; i < bytes.length; i += chunkSize) {
          binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunkSize)));
        }
        cachedArabicFont = btoa(binary);
      }
      
      // Use the dynamically determined font name
      const currentFontName = cachedArabicFont ? (cachedArabicFont.length > 1000 ? 'Amiri' : 'Amiri') : 'Amiri'; // We'll just use the variables we set
      // Wait, we need to store the font name in the cache or something if we want to reuse it.
      // For simplicity, let's just assume Amiri if cached, or we can just use a generic name 'ArabicFont'
      
      doc.addFileToVFS('ArabicFont.ttf', cachedArabicFont);
      doc.addFont('ArabicFont.ttf', 'ArabicFont', 'normal');
      doc.setFont('ArabicFont');
      settings.arabic_font_name = 'ArabicFont';
    } catch (e) {
      console.error('Failed to load Arabic font', e);
      doc.setFont('helvetica');
      settings.arabic_font_name = 'helvetica';
    }
  } else {
    doc.setFont('helvetica');
  }

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  
  let currentY = settings.margin_top;

  // Header
  if (settings.header_template) {
    doc.setFontSize(settings.subheading_font_size);
    doc.text(settings.header_template, isRTL ? pageWidth - settings.margin_right : settings.margin_left, currentY, { align: isRTL ? 'right' : 'left' });
    currentY += 30;
  }

  // Title
  doc.setFontSize(settings.heading_font_size);
  doc.text(title, pageWidth / 2, currentY, { align: 'center' });
  currentY += 40;

  for (const section of sections) {
    if (section.title) {
      doc.setFontSize(settings.subheading_font_size);
      doc.text(section.title, isRTL ? pageWidth - settings.margin_right : settings.margin_left, currentY, { align: isRTL ? 'right' : 'left' });
      currentY += 20;
    }

    if (section.type === 'text' && section.content) {
      doc.setFontSize(settings.arabic_font_size);
      const splitText = doc.splitTextToSize(section.content, pageWidth - settings.margin_left - settings.margin_right);
      doc.text(splitText, isRTL ? pageWidth - settings.margin_right : settings.margin_left, currentY, { align: isRTL ? 'right' : 'left' });
      currentY += (splitText.length * (settings.arabic_font_size + 4)) + 20;
    } else if (section.type === 'table' && section.columns && section.columns.length > 0 && section.data) {
      const tableBody = section.data.length > 0 
        ? section.data.map(row => section.columns!.map(c => {
            const val = row[c.dataKey];
            return val !== undefined && val !== null ? String(val) : '';
          }))
        : [[{ content: isRTL ? 'لا توجد بيانات' : 'No data available', colSpan: section.columns.length, styles: { halign: 'center' as const } }]];

      autoTable(doc, {
        startY: currentY,
        head: [section.columns.map(c => c.header)],
        body: tableBody,
        styles: {
          font: isRTL ? settings.arabic_font_name : 'helvetica',
          fontSize: settings.table_font_size,
          halign: isRTL ? 'right' : 'left',
        },
        headStyles: {
          fillColor: [41, 128, 185],
          textColor: 255,
          fontStyle: 'bold',
          halign: 'center'
        },
        margin: { 
          top: settings.margin_top, 
          right: settings.margin_right, 
          bottom: settings.margin_bottom, 
          left: settings.margin_left 
        },
        didDrawPage: (data: any) => {
          // Footer is drawn later for all pages
        }
      });
      currentY = (doc as any).lastAutoTable.finalY + 30;
    }
  }

  // Draw footer on all pages
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    if (settings.footer_template || settings.show_page_number === 1) {
      doc.setFontSize(10);
      const footerText = `${settings.footer_template} ${settings.show_page_number === 1 ? (isRTL ? `صفحة ${i}` : `Page ${i}`) : ''}`;
      doc.text(footerText, pageWidth / 2, pageHeight - settings.margin_bottom / 2, { align: 'center' });
    }
  }

  doc.save(`${title}.pdf`);
};
