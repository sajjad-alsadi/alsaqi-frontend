import { useState, useEffect } from 'react';
import api from '../services/api';

export interface Department {
  id: string;
  name: string;       // name_ar — always populated, safe for all legacy consumers
  name_ar: string;
  name_en: string | null;
  code: string;
  entity_type: string;
  parent_id: string | null;
  manager_name: string | null;
  level: number;
  status: string;
  display_order: number;
  children?: Department[];  // populated when using tree endpoint
}

let _cache: Department[] | null = null;
let _promise: Promise<Department[]> | null = null;

/**
 * Shared hook for all department dropdowns in the app.
 * Fetches once per page load and caches the result in module scope
 * so repeated calls in different components do not cause extra API requests.
 *
 * Usage:
 *   const { departments, loading } = useDepartments();
 *   // departments is always an array — never undefined
 */
export function useDepartments() {
  const [departments, setDepartments] = useState<Department[]>(_cache ?? []);
  const [loading, setLoading] = useState(!_cache);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (_cache) { setDepartments(_cache); setLoading(false); return; }

    if (!_promise) {
      _promise = api.get('/departments')
        .then(r => {
          _cache = Array.isArray(r.data) ? r.data : [];
          return _cache;
        })
        .catch(() => { _cache = []; return _cache; })
        .finally(() => { _promise = null; });
    }

    _promise.then(data => {
      setDepartments(data);
      setLoading(false);
    }).catch(e => {
      setError(String(e));
      setLoading(false);
    });
  }, []);

  /** Call this after a create/update/delete to refresh the cache */
  const refresh = () => {
    _cache = null;
    _promise = null;
    setLoading(true);
    api.get('/departments').then(r => {
      _cache = Array.isArray(r.data) ? r.data : [];
      setDepartments(_cache);
      setLoading(false);
    });
  };

  return { departments, loading, error, refresh };
}
