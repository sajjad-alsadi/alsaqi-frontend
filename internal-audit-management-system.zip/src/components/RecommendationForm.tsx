import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useTranslation } from 'react-i18next';
import { Recommendation, AuditFinding } from '../types';
import { AuditStatus, RiskLevel } from '../constants';
import CommentSection from './CommentSection';
import api from '../services/api';
import { Input } from './ui/Input';
import { Select } from './ui/Select';
import { FormField } from './ui/FormField';

const recommendationSchema = z.object({
  finding_id: z.string().min(1, 'Field is required'),
  department: z.string().min(1, 'Field is required'),
  responsible: z.string().min(1, 'Field is required'),
  due_date: z.string().min(1, 'Field is required'),
  status: z.nativeEnum(AuditStatus),
  risk_level: z.nativeEnum(RiskLevel),
});

type RecommendationFormValues = z.infer<typeof recommendationSchema>;

interface RecommendationFormProps {
  onSuccess: () => void;
  onCancel: () => void;
  findings: AuditFinding[];
  initialData?: Recommendation | null;
}

const RecommendationForm: React.FC<RecommendationFormProps> = ({ onSuccess, onCancel, findings, initialData }) => {
  const { t } = useTranslation();

  const {
    register,
    handleSubmit,
    reset,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<RecommendationFormValues>({
    resolver: zodResolver(recommendationSchema) as any,
    defaultValues: {
      finding_id: findings[0]?.id ? String(findings[0].id) : '',
      department: '',
      responsible: '',
      due_date: '',
      status: AuditStatus.OPEN,
      risk_level: RiskLevel.MEDIUM,
    },
  });

  const findingId = watch('finding_id');

  useEffect(() => {
    if (initialData) {
      const sanitized = { ...initialData };
      Object.keys(sanitized).forEach((key) => {
        if (sanitized[key as keyof Recommendation] === null) {
          (sanitized as any)[key] = '';
        }
      });
      reset(sanitized as any);
    }
  }, [initialData, reset]);

  const onSubmit = async (data: RecommendationFormValues) => {
    try {
      const url = initialData?.id 
        ? `/recommendations/${initialData.id}`
        : '/recommendations';
      
      if (initialData?.id) {
        await api.put(url, data);
      } else {
        await api.post(url, data);
      }
      onSuccess();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <FormField label={t('recommendations.recommendation')} className="md:col-span-2">
          <div className="p-6 bg-emerald-50/50 dark:bg-emerald-900/10 rounded-[1.5rem] border border-emerald-100 dark:border-emerald-900/30 text-sm font-black text-emerald-900 dark:text-emerald-400 leading-relaxed shadow-sm">
            {findings.find(f => String(f.id) === String(findingId))?.recommendation || t('recommendations.noRecommendationTextFound')}
          </div>
        </FormField>

        <FormField label={t('recommendations.department')} error={errors.department?.message} required>
          <Input {...register('department')} />
        </FormField>

        <FormField label={t('recommendations.responsible')} error={errors.responsible?.message} required>
          <Input {...register('responsible')} />
        </FormField>
        
        <FormField label={t('recommendations.dueDate')} error={errors.due_date?.message} required>
          <Input type="date" {...register('due_date')} />
        </FormField>

        <FormField label={t('recommendations.status')} error={errors.status?.message} required>
          <Select {...register('status')}>
            <option value={AuditStatus.OPEN}>{t('common.open')}</option>
            <option value={AuditStatus.IN_PROGRESS}>{t('common.inProgress')}</option>
            <option value={AuditStatus.IMPLEMENTED}>{t('common.implemented')}</option>
            <option value={AuditStatus.OVERDUE}>{t('common.overdue')}</option>
          </Select>
        </FormField>

        <FormField label={t('recommendations.riskLevel')} error={errors.risk_level?.message} required>
          <Select {...register('risk_level')}>
            {Object.values(RiskLevel).map((level) => (
              <option key={level} value={level}>{t('common.' + level.toLowerCase())}</option>
            ))}
          </Select>
        </FormField>
      </div>

      {initialData?.id && (
        <CommentSection relatedType="recommendation" relatedId={initialData.id} />
      )}

      <div className="flex justify-end gap-6 pt-8 border-t border-slate-100 dark:border-slate-800">
        <button
          type="button"
          onClick={onCancel}
          className="px-8 py-3 text-slate-500 dark:text-slate-400 font-black uppercase tracking-widest hover:bg-slate-100 dark:hover:bg-slate-800 rounded-[1.5rem] transition-all"
        >
          {t('common.cancel')}
        </button>
        <button
          type="submit"
          disabled={isSubmitting}
          className="btn-primary disabled:opacity-50"
        >
          {isSubmitting ? t('common.loading') : t('recommendations.save')}
        </button>
      </div>
    </form>
  );
};

export default RecommendationForm;

