import path from "path";
import crypto from "crypto";
import fs from "fs";

import logger from "./logger";
import { ValidationError } from "./errors";

export const ALLOWED_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.txt', '.csv'];
export const MIME_TO_EXT: Record<string, string[]> = {
  'image/jpeg': ['.jpg', '.jpeg'],
  'image/png': ['.png'],
  'image/gif': ['.gif'],
  'image/webp': ['.webp'],
  'application/pdf': ['.pdf'],
  'application/msword': ['.doc'],
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
  'application/vnd.ms-excel': ['.xls'],
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
  'text/plain': ['.txt'],
  'text/csv': ['.csv']
};

export const createSaveFile = (uploadDir: string) => async (file: any): Promise<string> => {
  const rawExt = path.extname(file.name).toLowerCase();
  
  // Security Check: Ensure extension is allowed
  if (!ALLOWED_EXTENSIONS.includes(rawExt)) {
    throw new ValidationError(`Extension ${rawExt} is not allowed`);
  }

  // Security Check: Cross-verify mimetype with extension
  const expectedExts = MIME_TO_EXT[file.mimetype];
  if (!expectedExts || !expectedExts.includes(rawExt)) {
    throw new ValidationError(`Mime-type mismatch for extension ${rawExt}`);
  }

  const baseName = path.basename(file.name, rawExt).replace(/[^a-zA-Z0-9]/g, '_');
  const fileName = `${Date.now()}-${crypto.randomBytes(4).toString('hex')}-${baseName}${rawExt}`;
  const uploadPath = path.join(uploadDir, fileName);
  
  await file.mv(uploadPath);
  return `/uploads/${fileName}`;
};

export const createLogError = (db: any) => async (err: any, module: string = "Backend") => {
  let errorMessage = "";
  let errorStack = null;

  if (err instanceof Error) {
    errorMessage = err.message;
    errorStack = err.stack || null;
  } else if (typeof err === 'object' && err !== null) {
    try {
      errorMessage = JSON.stringify(err);
    } catch (e) {
      errorMessage = String(err);
    }
  } else {
    errorMessage = String(err);
  }
  
  logger.error(`[${module}] ${errorMessage}`, { stack: errorStack, module });
  
  try {
    // Ensure we don't crash if DB is in a bad state
    const stmt = await db.prepare("INSERT INTO system_error_log (message, stack, module) VALUES (?::text, ?::text, ?::text)");
    await stmt.run(errorMessage, errorStack, module);
  } catch (e) {
    logger.error("CRITICAL: Failed to log error to DB.", { error: e });
  }
};
