import express from 'express';
import { z } from 'zod';
import { AuthService } from '../../services/AuthService';
import { asyncHandler } from '../../utils/asyncHandler';
import { validateSchema } from '../../middleware/validate';

const loginSchema = z.object({
  usernameOrEmail: z.string().min(1, "Username or Email is required").max(100),
  password: z.string().min(1, "Password is required").max(100),
});

export const createLoginRoutes = (
  db: any,
  JWT_SECRET: string,
  JWT_PRIVATE_KEY: string,
  authLimiter: any,
  logError: any
) => {
  const router = express.Router();

  router.post("/login", authLimiter, validateSchema(loginSchema), asyncHandler(async (req, res) => {
    const { usernameOrEmail, password } = req.body; // Safely typed and filtered by Zod middleware

    const result = await AuthService.login(usernameOrEmail, password, JWT_SECRET, JWT_PRIVATE_KEY, req.ip, req.get('user-agent'));

    // Always use sameSite: 'none' and secure: true to support AI Studio iframe preview
    // Note: sameSite: 'none' requires secure: true
    const cookieOptions: any = { 
      httpOnly: true, 
      secure: true, 
      sameSite: 'none', 
      path: '/' 
    };

    res.cookie('token', result.token, cookieOptions);
    
    // Refresh Token: Cookie-Only Storage
    res.cookie('refreshToken', result.refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      path: '/api/auth/refresh', // Restrict cookie path
      maxAge: 8 * 60 * 60 * 1000 // 8 hours in ms
    });

    await AuthService.logAudit(result.user.username, "Login", "Authentication", "User logged in");

    // Return ONLY the access token in the response body:
    res.json({ user: result.user, token: result.token });
  }));

  return router;
};
