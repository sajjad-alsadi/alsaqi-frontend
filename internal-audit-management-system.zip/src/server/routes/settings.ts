import express from 'express';
import { z } from 'zod';
import { SettingsService } from '../services/SettingsService';
import { asyncHandler } from '../utils/asyncHandler';
import { ValidationError } from '../utils/errors';
import { ADMIN_ROLES } from '../../constants';

const userManagementSettingsSchema = z.object({
  failed_login_threshold: z.coerce.number().int().min(1).max(20),
  inactive_account_threshold_days: z.coerce.number().int().min(1).max(365),
  password_min_length: z.coerce.number().int().min(6).max(32),
  session_timeout_minutes: z.coerce.number().int().min(1).max(1440)
});

export const createSettingsRoutes = (
  db: any,
  authenticate: any,
  authorize: any,
  logError: any
) => {
  const router = express.Router();

  router.get(`/user-management-settings`, authenticate, authorize(ADMIN_ROLES), asyncHandler(async (req, res) => {
    const settings = await SettingsService.getUserManagementSettings();
    res.json(settings);
  }));

  router.put(`/user-management-settings`, authenticate, authorize(ADMIN_ROLES), asyncHandler(async (req, res) => {
    const validation = userManagementSettingsSchema.safeParse(req.body);
    if (!validation.success) {
      throw new ValidationError("Invalid user management settings", validation.error.format());
    }
    await SettingsService.updateUserManagementSettings(validation.data);
    res.json({ success: true });
  }));

  return router;
};
