import bcrypt from "bcryptjs";
import { ROLES, MODULES, PERMISSIONS, DEFAULT_PERMISSIONS } from "../../permissions";

export const seedDatabase = async (db: any) => {
  // Check if seeding is already done (standard data)
  try {
    const hasData = await db.prepare("SELECT COUNT(*) as count FROM audit_plans").get() as any;
    if (hasData && hasData.count > 0) {
      console.log("[SEED] Audit plans already exist, skipping sample data seeding.");
      // Skip the rest of the sample data but ensure roles/admin etc. are present if we want
      // However, usually if plans exist, roles exist too.
      return;
    }
  } catch (e) {
    // Table might not exist yet if migrations failed, continue
  }

  // Initialize Roles and Permissions
  try {
    const insertPerm = db.prepare("INSERT INTO permissions (module, action) VALUES (?, ?) ON CONFLICT DO NOTHING");
    for (const module of Object.values(MODULES)) {
      for (const action of Object.values(PERMISSIONS)) {
        await insertPerm.run(module, action);
      }
    }

    const insertRole = db.prepare("INSERT INTO roles (name) VALUES (?) ON CONFLICT DO NOTHING");
    const getRoleId = db.prepare("SELECT id FROM roles WHERE name = ?");
    const getPermId = db.prepare("SELECT id FROM permissions WHERE module = ? AND action = ?");
    const insertRolePerm = db.prepare("INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?) ON CONFLICT DO NOTHING");

    for (const [roleName, modulePermissions] of Object.entries(DEFAULT_PERMISSIONS)) {
      await insertRole.run(roleName);
      const roleId = (await getRoleId.get(roleName) as any)?.id;

      if (roleId) {
        for (const [module, actions] of Object.entries(modulePermissions)) {
          for (const action of actions) {
            const permId = (await getPermId.get(module, action) as any)?.id;
            if (permId) {
              await insertRolePerm.run(roleId, permId);
            }
          }
        }
      }
    }

    const usersWithoutRoleId = await db.prepare("SELECT id, role FROM users WHERE role_id IS NULL").all() as any[];
    const updateUserId = db.prepare("UPDATE users SET role_id = ? WHERE id = ?");
    for (const user of usersWithoutRoleId) {
      const roleId = (await getRoleId.get(user.role) as any)?.id;
      if (roleId) {
        await updateUserId.run(roleId, user.id);
      }
    }
  } catch (error) {
    console.error("Error initializing roles and permissions:", error);
  }

  // Seed Admin User
  try {
    const adminExists = await db.prepare("SELECT * FROM users WHERE username = ?").get("admin") as any;
    const hashedPassword = bcrypt.hashSync("admin123", 10);
    
    if (!adminExists) {
      await db.prepare(`INSERT INTO users (username, password, name, email, role, department, failed_attempts) VALUES (?, ?, ?, ?, ?, ?, ?)`).run(
        "admin", hashedPassword, "System Administrator", "admin@fintech.com", "Admin", "IT", 0
      );
    } else {
      // In development, ensure admin password is reset to default and account is unlocked
      await db.prepare("UPDATE users SET password = ?, failed_attempts = 0, locked_until = NULL, status = 'Active', role = 'Admin' WHERE username = 'admin'").run(hashedPassword);
    }
  } catch (error) {
    console.error("Error seeding admin user:", error);
  }

  // Seed Sample System Error Log
  try {
    const admin = await db.prepare("SELECT id FROM users WHERE username = ?").get("admin");
    if (admin) {
      const hasLogs = await db.prepare("SELECT COUNT(*) as count FROM system_error_log").get() as any;
      if (hasLogs.count === 0) {
        await db.prepare(`INSERT INTO system_error_log (message, stack, module, user_id) VALUES (?::text, ?::text, ?::text, ?::uuid)`).run(
          "Sample database connection error", "Error: Connection timeout at database.ts:45", "Database", admin.id
        );
      }
    }
  } catch (error) {
    console.error("Error seeding sample error log:", error);
  }

  // Seed App Settings
  try {
    const settingsExists = await db.prepare("SELECT * FROM app_settings WHERE id = 1").get();
    if (!settingsExists) {
      await db.prepare(`INSERT INTO app_settings (id, app_name, app_version, app_description, company_name, system_owner, developer_name, release_date, last_update_date, support_email, support_phone, official_website, copyright_notice, system_environment, database_type, build_number, app_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
        1, "نظام التدقيق الداخلي", "1.0.0", "نظام متكامل لإدارة عمليات التدقيق الداخلي", "شركة التكنولوجيا المالية", "الإدارة العليا", "فريق التطوير", "2026-01-01", "2026-03-16", "support@fintech.com", "07700000000", "https://fintech.com", "© 2026 شركة التكنولوجيا المالية", "Production", "PostgreSQL", "1.0.0", "Active"
      );
    }

    const pdfSettingsExists = await db.prepare("SELECT * FROM pdf_settings WHERE id = 1").get();
    if (!pdfSettingsExists) {
      await db.prepare(`INSERT INTO pdf_settings (id, arabic_font_name, arabic_font_size, heading_font_size, subheading_font_size, table_font_size, rtl_enabled, margin_top, margin_right, margin_bottom, margin_left, logo_position, show_page_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
        1, 'Simplified Arabic', 14, 16, 14, 14, 1, 20, 20, 20, 20, 'right', 1
      );
    }

    const userManagementSettingsExists = await db.prepare("SELECT * FROM user_management_settings WHERE id = 1").get();
    if (!userManagementSettingsExists) {
      await db.prepare(`INSERT INTO user_management_settings (id, failed_login_threshold, inactive_account_threshold_days, password_min_length, session_timeout_minutes) VALUES (?, ?, ?, ?, ?)`).run(
        1, 3, 90, 8, 30
      );
    }
  } catch (error) {
    console.error("Error seeding settings:", error);
  }

  // Seed Departments
  try {
    const hasDepts = await db.prepare("SELECT COUNT(*) as count FROM departments").get() as any;
    if (hasDepts.count === 0) {
      const depts = [
        "قسم الشمول المالي", "قسم تطوير البرمجيات", "قسم الشؤون المالية", "قسم الشؤون القانونية",
        "قسم الإدارة والموارد البشرية", "قسم الامتثال", "قسم إدارة المخاطر", "قسم العلاقات العامة",
        "إدارة المشاريع", "قسم التسويات والمطابقة", "قسم العمليات", "قسم الإبلاغ عن غسل الأموال وتمويل الإرهاب",
        "أمن المعلومات", "مكتب المدير المفوض", "قسم الرقابة والتدقيق الداخلي", "قسم تقنية المعلومات",
        "قسم خدمة العملاء", "مكتب خدمة الزبائن - كربلاء", "مكتب خدمة الزبائن - النجف", "مكتب خدمة الزبائن - بغداد",
        "مكتب خدمة الزبائن - البصرة", "مكتب خدمة الزبائن - أربيل", "مراكز الإصدار الفوري للبطاقات"
      ];
      const deptStmt = db.prepare(`INSERT INTO departments (name) VALUES (?) ON CONFLICT DO NOTHING`);
      for (const d of depts) {
        await deptStmt.run(d);
      }
    }
  } catch (error) {
    console.error("Error seeding departments:", error);
  }

  // Seed Job Titles
  try {
    await db.prepare("DELETE FROM job_titles").run();
    const jobTitles = [
      ["مدير التدقيق الداخلي", "التدقيق الداخلي", "Manager", "إدارة وتوجيه كافة عمليات التدقيق الداخلي في الشركة", "Active"],
      ["مدقق تكنولوجيا المعلومات", "التدقيق الداخلي", "Senior", "تدقيق الأنظمة التقنية والبنية التحتية لأمن المعلومات", "Active"],
      ["أخصائي امتثال", "الامتثال", "Specialist", "مراقبة الامتثال لتعليمات البنك المركزي العراقي", "Active"],
      ["محلل تسويات مالية", "المالية", "Analyst", "مطابقة وتسوية حركات الدفع الإلكتروني اليومية", "Active"]
    ];
    const jobStmt = db.prepare(`INSERT INTO job_titles (name, department, job_level, description, status) VALUES (?, ?, ?, ?, ?)`);
    for (const j of jobTitles) {
      await jobStmt.run(...j);
    }
  } catch (error) {
    console.error("Error seeding job titles:", error);
  }

  // Seed Users
  try {
    const hashedPassword = bcrypt.hashSync("password123", 10);
    const users = [
      ["ahmed.ali", "أحمد علي", "ahmed.ali@alsaqi.iq", "Auditor", "قسم الرقابة والتدقيق الداخلي"],
      ["sara.hassan", "سارة حسن", "sara.hassan@alsaqi.iq", "Manager", "قسم التسويات والمطابقة"],
      ["omar.khalid", "عمر خالد", "omar.khalid@alsaqi.iq", "Auditor", "أمن المعلومات"]
    ];
    const userExists = db.prepare("SELECT id FROM users WHERE username = ?");
    const insertUser = db.prepare(`INSERT INTO users (username, password, name, email, role, department, status, failed_attempts) VALUES (?, ?, ?, ?, ?, ?, 'Active', 0)`);
    
    for (const u of users) {
      const exists = await userExists.get(u[0]);
      if (!exists) {
        await insertUser.run(u[0], hashedPassword, u[1], u[2], u[3], u[4]);
      }
    }
  } catch (error) {
    console.error("Error seeding additional users:", error);
  }

  // Seed System Policies
  try {
    const policyExists = await db.prepare("SELECT * FROM system_policies WHERE policy_key = ?").get("fraud_policy");
    if (!policyExists) {
      const defaultFraudPolicy = `وثيقة سياسة: إدارة سجل حالات الاحتيال (السري)
1. الهدف (Objective)
تهدف هذه السياسة إلى إرساء إطار عمل مؤسسي لتوثيق، وتتبع، وإدارة جميع ادعاءات وحالات الاحتيال (المشتبه بها والمؤكدة) بشكل منهجي وسري. يضمن هذا السجل الحفاظ على سلامة الأدلة، ويدعم تقييم المخاطر (Risk Assessment)، ويوفر قاعدة بيانات موثوقة لتعزيز الضوابط الرقابية الداخلية وفقاً لإطار (COSO) ومتطلبات البنك المركزي العراقي.

2. نطاق التطبيق (Scope)
تُطبق هذه السياسة على كافة إدارات المؤسسة وفروعها، وتشمل جميع البلاغات المتعلقة بالاحتيال الداخلي (من قبل الموظفين أو الإدارة) والاحتيال الخارجي (من قبل العملاء، أو الموردين، أو أطراف ثالثة)، بالإضافة إلى محاولات الاختراق المالي والتشغيلي.

3. المبادئ الأساسية والضوابط الرقابية
السرية التامة (Strict Confidentiality): يُصنف السجل كوثيقة "عالية السرية". يُحظر تداول محتوياته أو الإفصاح عنها إلا بناءً على مبدأ "الحاجة إلى المعرفة" (Need-to-Know Basis) وللأطراف المصرح لهم فقط.

الفصل بين المهام (Segregation of Duties): يجب فصل مسؤولية إدخال البيانات في السجل عن مسؤولية التحقيق في الحالات واتخاذ القرارات الإدارية بشأنها، لمنع أي تضارب في المصالح (Conflict of Interest).

مسار التدقيق (Audit Trail): يجب أن يخضع السجل (في حالته الإلكترونية) لن نظام تتبع يسجل كافة عمليات الدخول، والإضافة، والتعديل، مع تحديد هوية المستخدم ووقت الإجراء، بحيث لا يمكن حذف أو إخفاء أي سجل بمجرد إنشائه.

الشك المهني (Professional Skepticism): تُسجل جميع البلاغات في السجل كـ "حالات مشتبه بها" وتُعامل بجدية وموضوعية دون افتراض مسبق بالبراءة أو الإدانة، لحين جمع الأدلة القاطعة (Corroborative Evidence).`;
      await db.prepare("INSERT INTO system_policies (policy_key, content, updated_by) VALUES (?, ?, ?)").run("fraud_policy", defaultFraudPolicy, "system");
    }
  } catch (error) {
    console.error("Error seeding system policies:", error);
  }

  // Seed Sample Data
  try {
    // Clear existing sample data to replace with new ones
    await db.prepare("DELETE FROM audit_tasks").run();
    await db.prepare("DELETE FROM recommendations").run();
    await db.prepare("DELETE FROM audit_findings").run();
    await db.prepare("DELETE FROM audit_plans").run();
    await db.prepare("DELETE FROM risk_register").run();
    await db.prepare("DELETE FROM audit_procedures").run();
    await db.prepare("DELETE FROM audit_programs").run();
    await db.prepare("DELETE FROM fraud_log").run();
    await db.prepare("DELETE FROM central_bank_instructions").run();
    await db.prepare("DELETE FROM law_bank").run();
    await db.prepare("DELETE FROM outgoing_letters").run();
    await db.prepare("DELETE FROM incoming_correspondence").run();
    await db.prepare("DELETE FROM internal_policies").run();

    const plans = [
      ["تدقيق عمليات الدفع الإلكتروني والمحافظ الرقمية", "قسم العمليات", "Operational", "High", "2026-04-01", "2026-04-30", "Planned", "ahmed.ali", "AP-2026-001"],
      ["مراجعة امتثال أنظمة مكافحة غسل الأموال (AML)", "قسم الإبلاغ عن غسل الأموال وتمويل الإرهاب", "Compliance", "Critical", "2026-05-01", "2026-05-20", "Planned", "admin", "AP-2026-002"],
      ["تقييم أمن البنية التحتية لخوادم الدفع", "أمن المعلومات", "IT", "Critical", "2026-02-01", "2026-03-15", "In Progress", "omar.khalid", "AP-2026-003"],
      ["تدقيق إجراءات التسويات المالية مع البنك المركزي", "قسم التسويات والمطابقة", "Financial", "High", "2026-01-10", "2026-02-10", "Closed", "sara.hassan", "AP-2026-004"]
    ];
    const planStmt = db.prepare(`INSERT INTO audit_plans (title, department, type, risk_rating, planned_start_date, planned_end_date, status, lead_auditor, plan_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);
    const planIds = [];
    for (const p of plans) {
      const result = await planStmt.run(...p);
      planIds.push(result.lastInsertRowid);
    }

    // Seed Sample Risks
    const risks = [
      ["توقف نظام معالجة الحركات المالية (Switch) عن العمل", "قسم تقنية المعلومات", "IT", 2, 5, "Critical", "خوادم احتياطية (Disaster Recovery)، مراقبة 24/7", "تحديث خطة استمرارية الأعمال وإجراء تجارب وهمية", 10],
      ["احتيال مالي عبر بطاقات الدفع الإلكتروني المنسوخة", "قسم إدارة المخاطر", "Operational", 3, 4, "High", "نظام كشف الاحتيال (Fraud Management System)", "تطبيق معايير PCI-DSS بصرامة وتفعيل 3D Secure", 12],
      ["عدم الالتزام بتعليمات البنك المركزي العراقي الجديدة", "قسم الامتثال", "Compliance", 2, 5, "High", "متابعة دورية للتعاميم، وتدريب الموظفين", "إنشاء لجنة امتثال لمراجعة كافة التحديثات الرقابية", 10],
      ["أخطاء في تسويات حسابات التجار والوكلاء", "قسم التسويات والمطابقة", "Financial", 3, 3, "Medium", "مطابقة يومية يدوية وآلية", "تطوير نظام مطابقة آلي متكامل لتقليل التدخل البشري", 9]
    ];
    const riskStmt = db.prepare(`INSERT INTO risk_register (description, owner, type, likelihood, impact, rating, controls, mitigation, score) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);
    for (const r of risks) {
      await riskStmt.run(...r);
    }

    // Seed Sample Findings & Recommendations
    const findingStmt = db.prepare(`INSERT INTO audit_findings (audit_id, title, description, criteria, cause, consequence, recommendation, risk_level, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);
    const findingIds = [];
    if (planIds.length >= 4) {
      const f1 = await findingStmt.run(planIds[2], "ثغرات أمنية في خوادم التطبيق", "اكتشاف ثغرات أمنية غير معالجة في خوادم تطبيق الهاتف المحمول", "سياسة أمن المعلومات لشركة الساقي", "تأخر فريق الدعم الفني في تطبيق التحديثات الأمنية (Patches)", "احتمالية اختراق بيانات العملاء وتعطيل الخدمة", "التطبيق الفوري للتحديثات الأمنية وجدولة فحص اختراق دوري", "Critical", "Open");
      findingIds.push(f1.lastInsertRowid);
      
      const f2 = await findingStmt.run(planIds[3], "فروقات في حسابات التسوية", "وجود فروقات غير مبررة في حسابات التسوية مع بعض الوكلاء", "دليل إجراءات التسويات المالية", "اعتماد بعض الوكلاء على تقارير يدوية غير دقيقة", "خسائر مالية للشركة وعدم دقة في التقارير المالية", "إلزام جميع الوكلاء باستخدام بوابة الوكلاء الإلكترونية للمطابقة", "High", "Open");
      findingIds.push(f2.lastInsertRowid);
    }
    
    const recStmt = db.prepare(`INSERT INTO recommendations (finding_id, department, responsible, due_date, status, risk_level) VALUES (?, ?, ?, ?, ?, ?)`);
    if (findingIds.length >= 2) {
      await recStmt.run(findingIds[0], "أمن المعلومات", "مدير أمن المعلومات", "2026-03-25", "In Progress", "Critical");
      await recStmt.run(findingIds[1], "قسم التسويات والمطابقة", "مدير التسويات", "2026-04-10", "Open", "High");
    }

    const hasOrg = await db.prepare("SELECT COUNT(*) as count FROM org_entities").get() as any;
    if (hasOrg.count === 0) {
      const orgStmt = db.prepare(`
        INSERT INTO org_entities (entity_code, name_ar, name_en, entity_type, parent_id, manager_name, description, level) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      const bodResult = await orgStmt.run("BOD", "مجلس الإدارة", "Board of Directors", "Top Management", null, "Various Members", "Highest governing body", 1);
      const bodId = bodResult.lastInsertRowid;
      const ceoResult = await orgStmt.run("CEO", "المدير العام", "Chief Executive Officer", "Top Management", bodId, "Ahmad Al-Mansour", "Overall strategy and management", 2);
      const ceoId = ceoResult.lastInsertRowid;
      const dmdResult = await orgStmt.run("DMD", "معاون المدير العام", "Deputy Managing Director", "Top Management", ceoId, "Sarah Al-Saadi", "Operational oversight", 3);
      const dmdId = dmdResult.lastInsertRowid;

      const orgDepts = [
        ["IA", "قسم التدقيق الداخلي", "Internal Audit Department", "Department", ceoId, "Independent assurance", 3],
        ["COMP", "قسم الامتثال", "Compliance Department", "Department", ceoId, "Regulatory adherence", 3],
        ["RISK", "قسم إدارة المخاطر", "Risk Management Department", "Department", ceoId, "Risk identification and mitigation", 3],
        ["AML", "قسم مكافحة غسل الأموال", "AML Department", "Department", ceoId, "Anti-money laundering monitoring", 3],
        ["FIN", "قسم الشؤون المالية", "Financial Department", "Department", ceoId, "Financial planning and reporting", 3],
        ["OPS", "قسم العمليات", "Operations Department", "Department", dmdId, "Daily operations management", 4],
        ["IT", "قسم تقنية المعلومات", "IT Department", "Department", dmdId, "Technology infrastructure", 4],
        ["LEGAL", "قسم الشؤون القانونية", "Legal Department", "Department", ceoId, "Legal advisory", 3],
        ["HR", "قسم الموارد البشرية", "Human Resources Department", "Department", dmdId, "Talent management", 4]
      ];

      for (const d of orgDepts) {
        await orgStmt.run(d[0], d[1], d[2], d[3], d[4], null, d[5], d[6]);
      }
    }

    // Seed Conflict of Interest
    const hasCOI = await db.prepare("SELECT COUNT(*) as count FROM conflict_of_interest").get() as any;
    if (hasCOI.count === 0) {
      const adminUser = await db.prepare("SELECT id FROM users WHERE username = 'admin'").get() as any;
      if (adminUser) {
        await db.prepare(`INSERT INTO conflict_of_interest (user_id, user_name, declaration_date, description, status) VALUES (?, ?, ?, ?, ?)`).run(
          adminUser.id, "System Administrator", "2026-01-15", "لا توجد مصالح متعارضة حالياً", "approved"
        );
      }
    }
  } catch (error) {
    console.error("Error seeding sample data:", error);
  }

  // Seed Additional Modules if empty
  try {
    const progStmt = db.prepare(`INSERT INTO audit_programs (program_code, program_title, audit_area, department, audit_type, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)`);
    const prog1 = (await progStmt.run("PROG-2026-001", "برنامج تدقيق أمن بطاقات الدفع (PCI-DSS)", "تكنولوجيا المعلومات", "أمن المعلومات", "IT", "Approved", "admin")).lastInsertRowid;
    const prog2 = (await progStmt.run("PROG-2026-002", "برنامج مراجعة عمليات المحافظ الإلكترونية", "العمليات", "قسم العمليات", "Operational", "Approved", "admin")).lastInsertRowid;

    const procStmt = db.prepare(`INSERT INTO audit_procedures (program_id, procedure_number, audit_step, audit_test_description, risk_addressed) VALUES (?, ?, ?, ?, ?)`);
    await procStmt.run(prog1, "1.1", "فحص تشفير أرقام البطاقات (PAN)", "التأكد من عدم تخزين أرقام البطاقات بشكل واضح في قواعد البيانات واستخدام التشفير", "تسريب بيانات البطاقات");
    await procStmt.run(prog1, "1.2", "مراجعة صلاحيات الوصول للخوادم", "التحقق من أن الوصول لخوادم الدفع مقتصر على الموظفين المصرح لهم فقط", "اختراق داخلي");
    await procStmt.run(prog2, "2.1", "تدقيق حركات الإيداع والسحب", "أخذ عينة عشوائية من حركات المحافظ ومطابقتها مع السجلات المالية", "تلاعب في الأرصدة");
    await procStmt.run(prog2, "2.2", "مراجعة إجراءات فتح المحافظ الجديدة", "التأكد من استيفاء متطلبات KYC قبل تفعيل المحفظة للعميل", "غسل الأموال");

    const taskStmt = db.prepare(`INSERT INTO audit_tasks (audit_id, procedure, responsible, status) VALUES (?, ?, ?, ?)`);
    const plans = await db.prepare("SELECT id FROM audit_plans ORDER BY created_at ASC").all() as any[];
    if (plans.length >= 4) {
      await taskStmt.run(plans[2].id, "تنفيذ فحص اختراق (Penetration Test) على بوابة الدفع", "omar.khalid", "In Progress");
      await taskStmt.run(plans[2].id, "مراجعة سجلات الوصول (Access Logs) لقواعد البيانات", "omar.khalid", "Open");
      await taskStmt.run(plans[3].id, "مطابقة كشوفات البنك المركزي مع الحركات الداخلية لشهر فبراير", "sara.hassan", "Closed");
      await taskStmt.run(plans[3].id, "التأكد من تسوية عمولات الوكلاء بشكل صحيح", "sara.hassan", "Closed");
    }

    const lawStmt = db.prepare(`INSERT INTO law_bank (title, type, authority, issue_date, keywords) VALUES (?, ?, ?, ?, ?)`);
    await lawStmt.run("قانون الدفع الإلكتروني العراقي", "Law", "البنك المركزي العراقي", "2014-05-10", "دفع إلكتروني، بطاقات، محافظ");
    await lawStmt.run("قانون مكافحة غسل الأموال وتمويل الإرهاب رقم 39 لسنة 2015", "Law", "مجلس النواب", "2015-10-01", "غسل أموال، إرهاب، امتثال");

    const fraudStmt = db.prepare(`INSERT INTO fraud_log (incident_date, description, reported_by, status) VALUES (?, ?, ?, ?)`);
    await fraudStmt.run("2026-02-15", "محاولة احتيال عبر استنساخ بطاقة دفع (Skimming) في إحدى نقاط البيع", "قسم إدارة المخاطر", "Closed");
    await fraudStmt.run("2026-03-10", "ادعاء عميل بتحويل مبالغ من محفظته دون علمه (هندسة اجتماعية)", "قسم خدمة العملاء", "In Progress");

    const instStmt = db.prepare(`INSERT INTO central_bank_instructions (title, issue_date, reference_number, category, description, status) VALUES (?, ?, ?, ?, ?, ?)`);
    await instStmt.run("ضوابط تقديم خدمات الدفع الإلكتروني", "2025-11-20", "CBI/EPS/2025/11", "Operational", "تحديث ضوابط عمل شركات الدفع الإلكتروني ومزودي الخدمة", "Active");
    await instStmt.run("تعليمات العناية الواجبة تجاه عملاء المحافظ الإلكترونية", "2026-01-05", "CBI/AML/2026/01", "Compliance", "تشديد إجراءات التحقق من الهوية للحدود المالية العليا", "Active");

    const adminUser = await db.prepare("SELECT id FROM users WHERE username = 'admin'").get() as any;
    const adminId = adminUser ? adminUser.id : null;

    const outStmt = db.prepare(`INSERT INTO outgoing_letters (sequence_number, letter_date, recipient_entity, subject, classification, sending_method, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)`);
    await outStmt.run("OUT-2026-001", "2026-03-01", "البنك المركزي العراقي / دائرة المدفوعات", "تقرير الامتثال الربع سنوي لشركة الساقي", "Confidential", "بريد مسجل", adminId);
    await outStmt.run("OUT-2026-002", "2026-03-15", "شركة التدقيق الخارجي (PwC)", "تزويد ببيانات حركات الدفع لعام 2025", "Official", "Email", adminId);

    const incStmt = db.prepare(`INSERT INTO incoming_correspondence (sequence_number, letter_date, sender_entity, subject, classification, response_required, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
    await incStmt.run("INC-2026-001", "2026-03-05", "البنك المركزي العراقي", "إعمام بشأن إيقاف التعامل مع الكيانات المحظورة", "Official", 1, "Received", adminId);
    await incStmt.run("INC-2026-010", "2026-03-20", "شركة فيزا (Visa)", "تحديث متطلبات الأمان لبطاقات الدفع", "Official", 1, "In Progress", adminId);

    const polStmt = db.prepare(`INSERT INTO internal_policies (title, department, version, upload_date, file_url) VALUES (?, ?, ?, ?, ?)`);
    await polStmt.run("سياسة أمن معلومات الدفع الإلكتروني (PCI-DSS)", "أمن المعلومات", "V3.0", "2026-01-10", "#");
    await polStmt.run("دليل إجراءات تسوية منازعات حركات البطاقات (Chargeback)", "قسم العمليات", "V2.1", "2026-02-20", "#");
  } catch (error) {
    console.error("Error seeding additional modules:", error);
  }
};
