import { db } from "./index";

export const runMigrations = async () => {
  // Test connection first to avoid multiple connection errors
  try {
    await db.prepare("SELECT 1").get();
  } catch (e: any) {
    if (e.message?.includes('ECONNREFUSED') || e.message?.includes('connection timeout') || e.message?.includes('Connection terminated')) {
      console.error("[DB] CRITICAL: Database connection failed. Migrations cannot proceed.");
      console.error("[DB] Error details:", e.message);
      throw e; // Stop migrations if we can't connect
    }
    // Other errors (like table not existing) might be fine at this stage
  }

  // Core tables
  const coreTables = [
    `CREATE TABLE IF NOT EXISTS users (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      name TEXT NOT NULL,
      email TEXT,
      department TEXT,
      role TEXT DEFAULT 'user',
      status TEXT DEFAULT 'active',
      last_login TIMESTAMP,
      failed_attempts INTEGER DEFAULT 0,
      locked_until TIMESTAMP,
      profile_picture TEXT,
      language TEXT DEFAULT 'en',
      theme TEXT DEFAULT 'light',
      dashboard_layout TEXT DEFAULT 'standard',
      notifications_enabled INTEGER DEFAULT 1,
      job_title_id UUID,
      role_id UUID,
      unit TEXT,
      reporting_manager_id UUID,
      access_scope TEXT,
      phone_number TEXT,
      notes TEXT,
      session_version INTEGER DEFAULT 1,
      requires_password_change INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS audit_programs (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      program_code TEXT,
      program_title TEXT,
      audit_area TEXT,
      department TEXT,
      audit_type TEXT,
      audit_objective TEXT,
      audit_scope TEXT,
      key_risks TEXT,
      control_objectives TEXT,
      reference_standard TEXT,
      status TEXT,
      version_number TEXT,
      created_by TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS audit_plans (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      plan_code TEXT UNIQUE,
      program_id UUID,
      title TEXT NOT NULL,
      department TEXT,
      type TEXT,
      risk_rating TEXT,
      planned_start_date TEXT,
      planned_end_date TEXT,
      status TEXT,
      lead_auditor TEXT,
      team_members TEXT,
      objectives TEXT,
      scope TEXT,
      notes TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(program_id) REFERENCES audit_programs(id)
    )`,
    `CREATE TABLE IF NOT EXISTS audit_procedures (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      program_id UUID,
      procedure_number TEXT,
      audit_step TEXT,
      audit_test_description TEXT,
      risk_addressed TEXT,
      control_test_type TEXT,
      expected_evidence TEXT,
      sampling_method TEXT,
      responsible_auditor TEXT,
      remarks TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(program_id) REFERENCES audit_programs(id)
    )`,
    `CREATE TABLE IF NOT EXISTS audit_findings (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      audit_id UUID,
      title TEXT NOT NULL,
      description TEXT,
      criteria TEXT,
      condition TEXT,
      cause TEXT,
      consequence TEXT,
      recommendation TEXT,
      risk_level TEXT,
      status TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(audit_id) REFERENCES audit_plans(id)
    )`,
    `CREATE TABLE IF NOT EXISTS recommendations (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      finding_id UUID,
      department TEXT,
      responsible TEXT,
      due_date TEXT,
      status TEXT,
      risk_level TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(finding_id) REFERENCES audit_findings(id)
    )`,
    `CREATE TABLE IF NOT EXISTS risk_register (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      risk_id TEXT,
      description TEXT,
      owner TEXT,
      source TEXT,
      early_warning TEXT,
      type TEXT,
      likelihood TEXT,
      impact TEXT,
      score INTEGER,
      rating TEXT,
      controls TEXT,
      control_assessment TEXT,
      mitigation TEXT,
      treatment_option TEXT,
      residual_likelihood TEXT,
      residual_impact TEXT,
      residual_score INTEGER,
      residual_rating TEXT,
      status TEXT,
      target_date TEXT,
      review_date TEXT,
      notes TEXT,
      entry_date TEXT,
      entered_by TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS central_bank_instructions (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      title TEXT,
      issue_date TEXT,
      reference_number TEXT,
      category TEXT,
      description TEXT,
      related_department TEXT,
      attachment TEXT,
      status TEXT,
      related_instruction_id UUID,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS audit_trail (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      "user" TEXT NOT NULL,
      action TEXT NOT NULL,
      module TEXT NOT NULL,
      details TEXT,
      timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS internal_policies (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      title TEXT NOT NULL,
      department TEXT NOT NULL,
      version TEXT NOT NULL,
      upload_date TEXT NOT NULL,
      file_url TEXT NOT NULL,
      status TEXT DEFAULT 'active',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`
  ];

  for (const tableSql of coreTables) {
    try {
      await db.prepare(tableSql).run();
    } catch (e) {
      console.error("Error creating core table:", e);
    }
  }

  // Roles and Permissions tables
  const userManagementTables = [
    `CREATE TABLE IF NOT EXISTS audit_tasks (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      task_number VARCHAR(30) UNIQUE NOT NULL,
      title TEXT NOT NULL,
      plan_id UUID NOT NULL REFERENCES audit_plans(id),
      program_id UUID REFERENCES audit_programs(id),
      audit_type TEXT NOT NULL, 
      status TEXT NOT NULL DEFAULT 'draft',
      assigned_to UUID REFERENCES users(id),
      audited_unit_id UUID REFERENCES org_entities(id),
      planned_hours INTEGER,
      actual_hours INTEGER DEFAULT 0,
      period_from DATE,
      period_to DATE,
      due_date DATE,
      approved_by UUID REFERENCES users(id),
      approved_at TIMESTAMPTZ,
      created_by UUID REFERENCES users(id),
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      deleted_at TIMESTAMPTZ
    )`,
    `CREATE TABLE IF NOT EXISTS finding_risks (
      finding_id UUID NOT NULL REFERENCES audit_findings(id),
      risk_id UUID NOT NULL REFERENCES risk_register(id),
      PRIMARY KEY (finding_id, risk_id)
    )`,
    `CREATE TABLE IF NOT EXISTS finding_compliance (
      finding_id UUID NOT NULL REFERENCES audit_findings(id),
      compliance_id UUID NOT NULL REFERENCES central_bank_instructions(id),
      PRIMARY KEY (finding_id, compliance_id)
    )`,
    `CREATE TABLE IF NOT EXISTS compliance_items (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      ref_number TEXT NOT NULL,
      title TEXT NOT NULL,
      type TEXT NOT NULL,
      issuing_authority TEXT,
      issue_date DATE,
      effective_date DATE,
      compliance_status TEXT DEFAULT 'under_review',
      responsible_person_id UUID REFERENCES users(id),
      attachment_path TEXT,
      notes TEXT,
      created_by UUID REFERENCES users(id),
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS law_bank (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      title TEXT NOT NULL,
      type TEXT,
      authority TEXT,
      issue_date TEXT,
      keywords TEXT,
      bookmarked INTEGER DEFAULT 0,
      file_url TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS fraud_log (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      incident_date TEXT,
      description TEXT,
      reported_by TEXT,
      status TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS audit_reports (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      audit_id UUID,
      title TEXT,
      report_type INTEGER,
      generated_by TEXT,
      date_generated TEXT,
      status TEXT,
      content TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(audit_id) REFERENCES audit_plans(id)
    )`,
    `CREATE TABLE IF NOT EXISTS system_error_log (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      message TEXT NOT NULL,
      stack TEXT,
      module TEXT NOT NULL,
      user_id UUID,
      severity TEXT DEFAULT 'error',
      user_agent TEXT,
      url TEXT,
      request_data TEXT,
      timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`,
    `CREATE TABLE IF NOT EXISTS job_titles (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      name TEXT NOT NULL,
      department TEXT NOT NULL,
      job_level TEXT NOT NULL,
      description TEXT,
      reporting_to UUID,
      status TEXT NOT NULL DEFAULT 'active',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS outgoing_letters (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      sequence_number TEXT NOT NULL,
      letter_date TEXT NOT NULL,
      recipient_entity TEXT NOT NULL,
      subject TEXT NOT NULL,
      classification TEXT NOT NULL,
      sending_method TEXT NOT NULL,
      attachment_file TEXT,
      created_by TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      is_archived INTEGER DEFAULT 0
    )`,
    `DROP TABLE IF EXISTS app_settings`,
    `CREATE TABLE IF NOT EXISTS app_settings (
      id INTEGER PRIMARY KEY,
      app_name TEXT,
      app_version TEXT,
      app_description TEXT,
      company_name TEXT,
      system_owner TEXT,
      developer_name TEXT,
      release_date TEXT,
      last_update_date TEXT,
      support_email TEXT,
      support_phone TEXT,
      official_website TEXT,
      copyright_notice TEXT,
      system_environment TEXT,
      database_type TEXT,
      build_number TEXT,
      app_status TEXT DEFAULT 'Active'
    )`,
    `CREATE TABLE IF NOT EXISTS refresh_tokens (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id UUID NOT NULL,
      token TEXT UNIQUE NOT NULL,
      expires_at TIMESTAMP NOT NULL,
      is_revoked INTEGER DEFAULT 0,
      revoked_at TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    )`,
    `CREATE TABLE IF NOT EXISTS system_policies (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      policy_key TEXT UNIQUE NOT NULL,
      content TEXT NOT NULL,
      updated_by TEXT,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `DROP TABLE IF EXISTS pdf_settings`,
    `CREATE TABLE IF NOT EXISTS pdf_settings (
      id INTEGER PRIMARY KEY,
      arabic_font_name TEXT DEFAULT 'Simplified Arabic',
      arabic_font_size INTEGER DEFAULT 14,
      heading_font_size INTEGER DEFAULT 16,
      subheading_font_size INTEGER DEFAULT 14,
      table_font_size INTEGER DEFAULT 14,
      rtl_enabled INTEGER DEFAULT 1,
      margin_top INTEGER DEFAULT 20,
      margin_right INTEGER DEFAULT 20,
      margin_bottom INTEGER DEFAULT 20,
      margin_left INTEGER DEFAULT 20,
      header_template TEXT DEFAULT '',
      footer_template TEXT DEFAULT '',
      logo_position TEXT DEFAULT 'right',
      show_page_number INTEGER DEFAULT 1
    )`,
    `CREATE TABLE IF NOT EXISTS notifications (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id UUID NOT NULL,
      event_type TEXT NOT NULL,
      description TEXT NOT NULL,
      related_module TEXT,
      link TEXT,
      status TEXT DEFAULT 'Unread',
      date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS password_reset_requests (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id UUID NOT NULL,
      username TEXT NOT NULL,
      name TEXT NOT NULL,
      department TEXT,
      status TEXT DEFAULT 'Pending',
      request_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS password_history (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id UUID NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS fraud_access_requests (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id UUID NOT NULL,
      user_name TEXT NOT NULL,
      reason TEXT NOT NULL,
      status TEXT DEFAULT 'Pending',
      request_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS conflict_of_interest (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id UUID NOT NULL,
      user_name TEXT NOT NULL,
      declaration_date TEXT NOT NULL,
      description TEXT NOT NULL,
      related_party TEXT,
      status TEXT DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS org_structure (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      title TEXT NOT NULL,
      department TEXT NOT NULL,
      unit TEXT,
      employee_name TEXT,
      reporting_to UUID,
      role_description TEXT,
      access_level TEXT
    )`,
    `CREATE TABLE IF NOT EXISTS audit_evidence (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      audit_id UUID,
      finding_id UUID,
      type TEXT,
      description TEXT,
      uploaded_by TEXT,
      upload_date TEXT,
      file_name TEXT,
      file_data TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(audit_id) REFERENCES audit_plans(id),
      FOREIGN KEY(finding_id) REFERENCES audit_findings(id)
    )`,
    `CREATE TABLE IF NOT EXISTS roles (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      name TEXT UNIQUE NOT NULL,
      description TEXT,
      is_custom INTEGER DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS permissions (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      module TEXT NOT NULL,
      action TEXT NOT NULL,
      description TEXT,
      UNIQUE(module, action)
    )`,
    `CREATE TABLE IF NOT EXISTS role_permissions (
      role_id UUID NOT NULL,
      permission_id UUID NOT NULL,
      PRIMARY KEY (role_id, permission_id),
      FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
      FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
    )`,
    `CREATE TABLE IF NOT EXISTS user_permissions (
      user_id UUID NOT NULL,
      permission_id UUID NOT NULL,
      is_allowed INTEGER DEFAULT 1,
      PRIMARY KEY (user_id, permission_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
    )`,
    `CREATE TABLE IF NOT EXISTS login_history (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id UUID,
      username TEXT,
      login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      logout_time TIMESTAMP,
      ip_address TEXT,
      user_agent TEXT,
      device TEXT,
      browser TEXT,
      status TEXT NOT NULL, -- Success, Failed, Locked
      failure_reason TEXT,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`,
    `CREATE TABLE IF NOT EXISTS user_sessions (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id UUID NOT NULL,
      session_token TEXT UNIQUE NOT NULL,
      refresh_token TEXT,
      login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      status TEXT DEFAULT 'Active', -- Active, Terminated, Expired
      ip_address TEXT,
      device TEXT,
      browser TEXT,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`,
    `CREATE TABLE IF NOT EXISTS permission_change_logs (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      target_user_id UUID NOT NULL,
      changed_by_id UUID NOT NULL,
      old_role TEXT,
      new_role TEXT,
      old_permissions TEXT, -- JSON string
      new_permissions TEXT, -- JSON string
      change_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      reason TEXT,
      FOREIGN KEY (target_user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (changed_by_id) REFERENCES users(id) ON DELETE CASCADE
    )`,
    `DROP TABLE IF EXISTS user_management_settings`,
    `CREATE TABLE IF NOT EXISTS user_management_settings (
      id INTEGER PRIMARY KEY,
      failed_login_threshold INTEGER DEFAULT 3,
      inactive_account_threshold_days INTEGER DEFAULT 90,
      password_min_length INTEGER DEFAULT 8,
      password_require_uppercase INTEGER DEFAULT 1,
      password_require_lowercase INTEGER DEFAULT 1,
      password_require_numbers INTEGER DEFAULT 1,
      password_require_symbols INTEGER DEFAULT 1,
      password_expiry_days INTEGER DEFAULT 90,
      enforce_single_session INTEGER DEFAULT 0,
      session_timeout_minutes INTEGER DEFAULT 30,
      bulk_import_enabled INTEGER DEFAULT 1,
      admin_approval_required INTEGER DEFAULT 0
    )`,
    `CREATE TABLE IF NOT EXISTS org_entities (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      entity_code TEXT UNIQUE NOT NULL,
      name_ar TEXT NOT NULL,
      name_en TEXT NOT NULL,
      entity_type TEXT NOT NULL, -- Top Management, Department, Division, Unit, Branch, Office, Committee, Other
      parent_id UUID,
      manager_id UUID,
      manager_name TEXT,
      level INTEGER DEFAULT 1,
      status TEXT DEFAULT 'Active', -- Active, Inactive, Archived
      description TEXT,
      display_order INTEGER DEFAULT 0,
      location TEXT,
      cost_center_code TEXT,
      notes TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (parent_id) REFERENCES org_entities(id),
      FOREIGN KEY (manager_id) REFERENCES users(id)
    )`,
    `CREATE TABLE IF NOT EXISTS departments (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      name TEXT UNIQUE NOT NULL,
      description TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS incoming_correspondence (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      sequence_number TEXT UNIQUE NOT NULL,
      letter_number TEXT,
      sender_entity TEXT NOT NULL,
      sender_entity_type TEXT,
      subject TEXT NOT NULL,
      letter_date DATE,
      receipt_date DATE,
      registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      classification TEXT,
      priority TEXT DEFAULT 'Normal',
      method TEXT,
      receiving_dept_id UUID,
      assigned_dept_id UUID,
      assigned_user_id UUID,
      status TEXT DEFAULT 'Received',
      follow_up_required INTEGER DEFAULT 0,
      follow_up_date DATE,
      response_required INTEGER DEFAULT 0,
      response_due_date DATE,
      notes TEXT,
      created_by UUID,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      is_archived INTEGER DEFAULT 0,
      FOREIGN KEY (receiving_dept_id) REFERENCES org_entities(id),
      FOREIGN KEY (assigned_dept_id) REFERENCES org_entities(id),
      FOREIGN KEY (assigned_user_id) REFERENCES users(id),
      FOREIGN KEY (created_by) REFERENCES users(id)
    )`,
    `CREATE TABLE IF NOT EXISTS outgoing_correspondence (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      sequence_number TEXT UNIQUE NOT NULL,
      official_number TEXT UNIQUE,
      letter_date DATE,
      registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      recipient_entity TEXT NOT NULL,
      recipient_entity_type TEXT,
      subject TEXT NOT NULL,
      classification TEXT,
      priority TEXT DEFAULT 'Normal',
      method TEXT,
      status TEXT DEFAULT 'Draft',
      source_dept_id UUID,
      sent_date TIMESTAMP,
      delivery_ref TEXT,
      recipient_contact TEXT,
      notes TEXT,
      created_by UUID,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      is_archived INTEGER DEFAULT 0,
      FOREIGN KEY (source_dept_id) REFERENCES org_entities(id),
      FOREIGN KEY (created_by) REFERENCES users(id)
    )`,
    `CREATE TABLE IF NOT EXISTS correspondence_attachments (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      correspondence_id UUID NOT NULL,
      correspondence_type TEXT NOT NULL, -- 'Incoming' or 'Outgoing'
      file_name TEXT NOT NULL,
      file_type TEXT,
      file_data TEXT, -- Base64 or URL
      description TEXT,
      uploaded_by UUID,
      uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (uploaded_by) REFERENCES users(id)
    )`,
    `CREATE TABLE IF NOT EXISTS correspondence_referrals (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      incoming_id UUID NOT NULL,
      from_user_id UUID NOT NULL,
      to_dept_id UUID,
      to_user_id UUID,
      referral_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      notes TEXT,
      status TEXT DEFAULT 'Pending',
      FOREIGN KEY (incoming_id) REFERENCES incoming_correspondence(id),
      FOREIGN KEY (from_user_id) REFERENCES users(id),
      FOREIGN KEY (to_dept_id) REFERENCES org_entities(id),
      FOREIGN KEY (to_user_id) REFERENCES users(id)
    )`,
    `CREATE TABLE IF NOT EXISTS correspondence_links (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      incoming_id UUID NOT NULL,
      outgoing_id UUID NOT NULL,
      link_type TEXT DEFAULT 'Reply',
      linked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      linked_by UUID,
      UNIQUE(incoming_id, outgoing_id),
      FOREIGN KEY (incoming_id) REFERENCES incoming_correspondence(id),
      FOREIGN KEY (outgoing_id) REFERENCES outgoing_letters(id),
      FOREIGN KEY (linked_by) REFERENCES users(id)
    )`,
    `CREATE TABLE IF NOT EXISTS correspondence_status_history (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      correspondence_id UUID NOT NULL,
      correspondence_type TEXT NOT NULL,
      old_status TEXT,
      new_status TEXT,
      changed_by UUID,
      change_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      notes TEXT,
      FOREIGN KEY (changed_by) REFERENCES users(id)
    )`,
    `CREATE TABLE IF NOT EXISTS incoming_letters (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      sequence_number TEXT UNIQUE NOT NULL,
      letter_date DATE,
      sender_entity TEXT,
      subject TEXT,
      classification TEXT,
      status TEXT DEFAULT 'Open',
      response_required INTEGER DEFAULT 0,
      attachment_file TEXT,
      created_by TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS outgoing_letters (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      sequence_number TEXT UNIQUE NOT NULL,
      letter_date DATE,
      recipient_entity TEXT,
      subject TEXT,
      classification TEXT,
      sending_method TEXT,
      attachment_file TEXT,
      created_by TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      is_archived INTEGER DEFAULT 0
    )`
  ];

  for (const tableSql of userManagementTables) {
    try {
      await db.prepare(tableSql).run();
    } catch (e) {
      console.error("Error creating user management table:", e);
    }
  }

  // Add refresh_token to user_sessions if it doesn't exist
  try {
    const tableInfo = await db.prepare("SELECT column_name FROM information_schema.columns WHERE table_name = 'user_sessions'").all() as any[];
    const hasRefreshToken = tableInfo.some(col => col.column_name === 'refresh_token');
    if (!hasRefreshToken) {
      await db.prepare("ALTER TABLE user_sessions ADD COLUMN refresh_token TEXT").run();
      console.log("Added refresh_token column to user_sessions table");
    }
  } catch (e) {
    console.error("Error adding refresh_token column:", e);
  }

  // Add missing columns to system_error_log if they don't exist
  try {
    const tableInfo = await db.prepare("SELECT column_name FROM information_schema.columns WHERE table_name = 'system_error_log'").all() as any[];
    const hasSeverity = tableInfo.some(col => col.column_name === 'severity');
    if (!hasSeverity) {
      await db.prepare("ALTER TABLE system_error_log ADD COLUMN severity TEXT DEFAULT 'error'").run();
      await db.prepare("ALTER TABLE system_error_log ADD COLUMN user_agent TEXT").run();
      await db.prepare("ALTER TABLE system_error_log ADD COLUMN url TEXT").run();
      await db.prepare("ALTER TABLE system_error_log ADD COLUMN request_data TEXT").run();
      console.log("Added missing columns to system_error_log table");
    }
  } catch (e) {
    console.error("Error adding columns to system_error_log:", e);
  }

  // Comments table
  try {
    await db.prepare(`
      CREATE TABLE IF NOT EXISTS comments (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        related_type TEXT NOT NULL,
        related_id UUID NOT NULL,
        user_id UUID NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
      )
    `).run();
  } catch (e) {
    console.error("Error creating comments table:", e);
  }

  // Column Migrations
  const migrations = [
    { table: "audit_findings", column: "finding_number", type: "VARCHAR(50) UNIQUE" },
    { table: "audit_findings", column: "finding_type", type: "TEXT" },
    { table: "audit_findings", column: "impact", type: "TEXT" },
    { table: "audit_findings", column: "root_cause", type: "TEXT" },
    { table: "audit_findings", column: "responsible_unit_id", type: "UUID REFERENCES org_entities(id)" },
    { table: "audit_findings", column: "risk_id", type: "UUID REFERENCES risk_register(id)" },
    { table: "audit_findings", column: "created_by", type: "UUID REFERENCES users(id)" },
    { table: "audit_findings", column: "deleted_at", type: "TIMESTAMPTZ" },
    { table: "recommendations", column: "rec_number", type: "VARCHAR(70) UNIQUE" },
    { table: "recommendations", column: "action_plan", type: "TEXT" },
    { table: "recommendations", column: "responsible_person_id", type: "UUID REFERENCES users(id)" },
    { table: "recommendations", column: "priority", type: "TEXT DEFAULT 'medium'" },
    { table: "recommendations", column: "follow_up_date", type: "DATE" },
    { table: "recommendations", column: "closure_evidence_path", type: "TEXT" },
    { table: "recommendations", column: "closed_by", type: "UUID REFERENCES users(id)" },
    { table: "recommendations", column: "closed_at", type: "TIMESTAMPTZ" },
    { table: "recommendations", column: "created_by", type: "UUID REFERENCES users(id)" },
    { table: "risk_register", column: "likelihood_num", type: "INTEGER CHECK(likelihood_num BETWEEN 1 AND 5)" },
    { table: "risk_register", column: "impact_num", type: "INTEGER CHECK(impact_num BETWEEN 1 AND 5)" },
    { table: "risk_register", column: "risk_score_calc", type: "INTEGER" },
    { table: "risk_register", column: "risk_level_calc", type: "TEXT" },
    { table: "audit_plans", column: "updated_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "audit_tasks", column: "updated_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "audit_procedures", column: "updated_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "audit_evidence", column: "created_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "audit_evidence", column: "updated_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "risk_register", column: "created_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "risk_register", column: "updated_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "fraud_log", column: "updated_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "central_bank_instructions", column: "created_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "central_bank_instructions", column: "updated_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "law_bank", column: "updated_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "audit_reports", column: "updated_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "audit_findings", column: "created_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "audit_findings", column: "updated_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "recommendations", column: "created_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "recommendations", column: "updated_at", type: "TIMESTAMP DEFAULT CURRENT_TIMESTAMP" },
    { table: "fraud_access_requests", column: "expires_at", type: "TIMESTAMP" },
    { table: "fraud_access_requests", column: "response_date", type: "TIMESTAMP" },
    { table: "fraud_access_requests", column: "responded_by", type: "UUID" },
    { table: "fraud_access_requests", column: "rejection_reason", type: "TEXT" },
    { table: "conflict_of_interest", column: "reviewer_notes", type: "TEXT" },
    { table: "users", column: "password_last_changed", type: "TIMESTAMP" },
    { table: "users", column: "org_entity_id", type: "UUID" },
    { table: "users", column: "division_id", type: "UUID" },
    { table: "users", column: "unit_id", type: "UUID" },
    { table: "password_reset_requests", column: "temp_password", type: "TEXT" },
    { table: "password_reset_requests", column: "resolved_date", type: "TIMESTAMP" },
    { table: "password_reset_requests", column: "resolved_by", type: "UUID" },
    { table: "users", column: "failed_attempts", type: "INTEGER DEFAULT 0" },
    { table: "users", column: "session_version", type: "INTEGER DEFAULT 1" },
    { table: "users", column: "requires_password_change", type: "INTEGER DEFAULT 0" },
    { table: "users", column: "role_id", type: "UUID" },
    { table: "users", column: "unit", type: "TEXT" },
    { table: "users", column: "reporting_manager_id", type: "UUID" },
    { table: "users", column: "access_scope", type: "TEXT" },
    { table: "users", column: "phone_number", type: "TEXT" },
    { table: "users", column: "notes", type: "TEXT" },
    { table: "audit_plans", column: "department", type: "TEXT" },
    { table: "audit_plans", column: "type", type: "TEXT" },
    { table: "audit_plans", column: "risk_rating", type: "TEXT" },
    { table: "audit_plans", column: "planned_start_date", type: "TEXT" },
    { table: "audit_plans", column: "planned_end_date", type: "TEXT" },
    { table: "audit_plans", column: "lead_auditor", type: "TEXT" },
    { table: "audit_plans", column: "notes", type: "TEXT" },
    { table: "audit_plans", column: "plan_code", type: "TEXT UNIQUE" },
    { table: "system_error_log", column: "severity", type: "TEXT DEFAULT 'error'" },
    { table: "system_error_log", column: "user_agent", type: "TEXT" },
    { table: "system_error_log", column: "url", type: "TEXT" },
    { table: "system_error_log", column: "request_data", type: "TEXT" },
    { table: "login_history", column: "user_agent", type: "TEXT" },
    { table: "audit_procedures", column: "control_test_type", type: "TEXT" },
    { table: "audit_procedures", column: "expected_evidence", type: "TEXT" },
    { table: "audit_procedures", column: "sampling_method", type: "TEXT" },
    { table: "audit_procedures", column: "responsible_auditor", type: "TEXT" },
    { table: "audit_procedures", column: "remarks", type: "TEXT" },
  ];

  for (const m of migrations) {
    try {
      console.log(`[MIGRATION] Attempting to add column ${m.column} to table ${m.table}`);
      await db.prepare(`ALTER TABLE ${m.table} ADD COLUMN IF NOT EXISTS ${m.column} ${m.type}`).run();
    } catch (e) {
      console.error(`Error adding column ${m.column} to ${m.table}:`, e);
    }
  }

  // Backfill plan_code for existing audit_plans
  try {
    const currentYear = new Date().getFullYear();
    // Use a more robust query to find plans without a valid code
    const existingPlans = await db.prepare("SELECT id, title FROM audit_plans WHERE plan_code IS NULL OR plan_code = '' OR plan_code NOT LIKE 'AP-%'").all();
    
    if (existingPlans && existingPlans.length > 0) {
      for (let i = 0; i < existingPlans.length; i++) {
        // Find the next available number for this year to avoid duplicates if some are already set
        const prefix = `AP-${currentYear}-`;
        const latest = await db.prepare("SELECT plan_code FROM audit_plans WHERE plan_code LIKE ? ORDER BY plan_code DESC LIMIT 1").get(`${prefix}%`) as any;
        
        let nextNum = 1;
        if (latest && latest.plan_code) {
          const parts = latest.plan_code.split('-');
          const lastNum = parseInt(parts[parts.length - 1]);
          if (!isNaN(lastNum)) {
            nextNum = lastNum + 1;
          }
        }
        
        const planCode = `${prefix}${nextNum.toString().padStart(3, '0')}`;
        await db.prepare("UPDATE audit_plans SET plan_code = ? WHERE id = ?").run(planCode, existingPlans[i].id);
      }
    }
  } catch (e) {
    console.error("[MIGRATION] Backfill failed:", e);
  }

  // Performance Indexes
  const indexes = [
    "CREATE INDEX IF NOT EXISTS idx_audit_trail_timestamp ON audit_trail(timestamp)",
    "CREATE INDEX IF NOT EXISTS idx_audit_trail_user ON audit_trail(\"user\")",
    "CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)",
    "CREATE INDEX IF NOT EXISTS idx_users_department ON users(department)",
    "CREATE INDEX IF NOT EXISTS idx_users_role ON users(role)",
    "CREATE INDEX IF NOT EXISTS idx_incoming_correspondence_is_archived ON incoming_correspondence(is_archived)",
    "CREATE INDEX IF NOT EXISTS idx_incoming_correspondence_status ON incoming_correspondence(status)",
    "CREATE INDEX IF NOT EXISTS idx_incoming_correspondence_seq ON incoming_correspondence(sequence_number)",
    "CREATE INDEX IF NOT EXISTS idx_incoming_correspondence_date ON incoming_correspondence(letter_date)",
    "CREATE INDEX IF NOT EXISTS idx_outgoing_correspondence_is_archived ON outgoing_correspondence(is_archived)",
    "CREATE INDEX IF NOT EXISTS idx_outgoing_correspondence_seq ON outgoing_correspondence(sequence_number)",
    "CREATE INDEX IF NOT EXISTS idx_outgoing_correspondence_date ON outgoing_correspondence(letter_date)",
    "CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id)",
    "CREATE INDEX IF NOT EXISTS idx_notifications_status ON notifications(status)",
    "CREATE INDEX IF NOT EXISTS idx_audit_plans_status ON audit_plans(status)",
    "CREATE INDEX IF NOT EXISTS idx_audit_plans_risk ON audit_plans(risk_rating)",
    "CREATE INDEX IF NOT EXISTS idx_audit_plans_program_id ON audit_plans(program_id)",
    "CREATE INDEX IF NOT EXISTS idx_audit_findings_audit_id ON audit_findings(audit_id)",
    "CREATE INDEX IF NOT EXISTS idx_audit_findings_risk ON audit_findings(risk_level)",
    "CREATE INDEX IF NOT EXISTS idx_audit_trail_module ON audit_trail(module)",
    "CREATE INDEX IF NOT EXISTS idx_audit_trail_action ON audit_trail(action)",
    "CREATE INDEX IF NOT EXISTS idx_risk_register_rating ON risk_register(rating)",
    "CREATE INDEX IF NOT EXISTS idx_risk_register_status ON risk_register(status)",
    "CREATE INDEX IF NOT EXISTS idx_recommendations_finding_id ON recommendations(finding_id)",
    "CREATE INDEX IF NOT EXISTS idx_audit_tasks_audit_id ON audit_tasks(audit_id)",
    "CREATE INDEX IF NOT EXISTS idx_audit_plans_type ON audit_plans(type)",
    "CREATE INDEX IF NOT EXISTS idx_audit_plans_department ON audit_plans(department)",
    "CREATE INDEX IF NOT EXISTS idx_risk_register_type ON risk_register(type)"
  ];

  for (const indexSql of indexes) {
    try {
      await db.prepare(indexSql).run();
    } catch (e) {
      console.error("Error creating index:", e);
    }
  }

  // Add missing columns to refresh_tokens if they don't exist
  try {
    const tableInfo = await db.prepare("SELECT column_name FROM information_schema.columns WHERE table_name = 'refresh_tokens'").all() as any[];
    const hasRevokedAt = tableInfo.some(col => col.column_name === 'revoked_at');
    if (!hasRevokedAt) {
      await db.prepare("ALTER TABLE refresh_tokens ADD COLUMN revoked_at TIMESTAMP").run();
      console.log("Added revoked_at column to refresh_tokens table");
    }
  } catch (e) {
    console.error("Error adding revoked_at column to refresh_tokens:", e);
  }

  // Set revoked_at for legacy revoked tokens to a very old date
  try {
    const tableInfo = await db.prepare("SELECT column_name FROM information_schema.columns WHERE table_name = 'refresh_tokens'").all() as any[];
    const hasRevokedAt = tableInfo.some(col => col.column_name === 'revoked_at');
    if (hasRevokedAt) {
      await db.prepare("UPDATE refresh_tokens SET revoked_at = '1970-01-01 00:00:00' WHERE is_revoked = 1 AND revoked_at IS NULL").run();
    }
  } catch (e) {
    console.error("Error backfilling revoked_at:", e);
  }

  // Add missing columns to outgoing_letters if they don't exist
  try {
    const tableInfo = await db.prepare("SELECT column_name FROM information_schema.columns WHERE table_name = 'outgoing_letters'").all() as any[];
    
    if (!tableInfo.some(col => col.column_name === 'is_archived')) {
      await db.prepare("ALTER TABLE outgoing_letters ADD COLUMN is_archived INTEGER DEFAULT 0").run();
    }
    if (!tableInfo.some(col => col.column_name === 'status')) {
      await db.prepare("ALTER TABLE outgoing_letters ADD COLUMN status TEXT DEFAULT 'Draft'").run();
    }
    if (!tableInfo.some(col => col.column_name === 'updated_at')) {
      await db.prepare("ALTER TABLE outgoing_letters ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP").run();
    }
  } catch (e) {
    console.error("Error adding columns to outgoing_letters:", e);
  }

  // Initialize user_management_settings if empty
  try {
    const settingsCount = await db.prepare("SELECT COUNT(*) as count FROM user_management_settings").get() as any;
    if (settingsCount.count === 0) {
      await db.prepare("INSERT INTO user_management_settings (id) VALUES (1)").run();
    }
  } catch (e) {
    console.error("Error initializing user_management_settings:", e);
  }

  // --- COMPLIANCE MATRIX MIGRATION START ---
  try {
    // Drop existing versions of these tables to redefine them (development approach)
    await db.prepare("DROP TABLE IF EXISTS finding_compliance CASCADE").run();
    await db.prepare("DROP TABLE IF EXISTS compliance_items CASCADE").run();

    await db.prepare(`
      CREATE TABLE IF NOT EXISTS compliance_items (
        id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),

        -- Identity
        ref_number            TEXT NOT NULL,
        title                 TEXT NOT NULL,
        source_type           TEXT NOT NULL,
        issuing_authority     TEXT,
        category              TEXT,

        -- Dates
        issue_date            TEXT,
        effective_date        TEXT,
        review_date           TEXT,

        -- Compliance tracking
        compliance_status     TEXT NOT NULL DEFAULT 'under_review',
        maturity_score        INTEGER CHECK(maturity_score BETWEEN 0 AND 100),
        gap_notes             TEXT,

        -- Ownership
        responsible_person_id UUID REFERENCES users(id),
        department_id         UUID REFERENCES org_entities(id),

        -- Content
        description           TEXT,
        keywords              TEXT,
        version               TEXT,
        attachment_path       TEXT,

        -- Meta
        created_by            UUID REFERENCES users(id),
        created_at            TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        updated_at            TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
        deleted_at            TIMESTAMPTZ
      )
    `).run();

    await db.prepare(`
      CREATE TABLE IF NOT EXISTS finding_compliance (
        finding_id     UUID NOT NULL REFERENCES audit_findings(id),
        compliance_id  UUID NOT NULL REFERENCES compliance_items(id),
        PRIMARY KEY (finding_id, compliance_id)
      )
    `).run();

    // Migrate data
    await db.prepare(`
      INSERT INTO compliance_items
        (ref_number, title, source_type, issuing_authority, category,
         issue_date, description, compliance_status, created_at)
      SELECT
        COALESCE(reference_number, 'REF-' || id::text),
        title,
        'cbi_instruction',
        'البنك المركزي العراقي',
        category,
        issue_date,
        description,
        CASE WHEN status = 'Active' THEN 'compliant' ELSE 'under_review' END,
        CURRENT_TIMESTAMP
      FROM central_bank_instructions
      WHERE title IS NOT NULL
    `).run();

    await db.prepare(`
      INSERT INTO compliance_items
        (ref_number, title, source_type, issuing_authority,
         issue_date, keywords, compliance_status, created_at)
      SELECT
        'LAW-' || id::text,
        title,
        'law',
        authority,
        issue_date,
        keywords,
        'under_review',
        CURRENT_TIMESTAMP
      FROM law_bank
      WHERE title IS NOT NULL
    `).run();

    await db.prepare(`
      INSERT INTO compliance_items
        (ref_number, title, source_type, version,
         issue_date, attachment_path, compliance_status, created_at)
      SELECT
        'POL-' || id::text,
        title,
        'internal_policy',
        version,
        upload_date,
        file_url,
        CASE WHEN status = 'Active' THEN 'compliant' ELSE 'under_review' END,
        CURRENT_TIMESTAMP
      FROM internal_policies
      WHERE title IS NOT NULL
    `).run();
  } catch (e) {
    console.error("Error creating compliance matrix tables:", e);
  }
  // --- COMPLIANCE MATRIX MIGRATION END ---

  console.log("Migrations completed successfully.");
};
