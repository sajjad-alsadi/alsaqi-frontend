import { db } from '../db/index';
import { NotFoundError, ValidationError, ForbiddenError } from '../utils/errors';

const ALLOWED_TRANSITIONS: Record<string, Record<string, { roles: string[] }>> = {
  'draft': {
    'in_progress': { roles: ['Auditor', 'Internal Auditor', 'Manager'] }
  },
  'in_progress': {
    'review': { roles: ['Auditor', 'Internal Auditor'] }
  },
  'review': {
    'approved': { roles: ['Manager'] },
    'in_progress': { roles: ['Manager'] }
  },
  'approved': {
    'completed': { roles: ['Manager'] }
  }
};

export class AuditTaskService {
  static async changeStatus(taskId: string, newStatus: string, userId: string, userRole: string, _db: any) {
    const database = _db || db;
    const task = await database.prepare('SELECT * FROM audit_tasks WHERE id = ?').get(taskId) as any;
    
    if (!task) throw new NotFoundError('IAMS-NOT-001');
    
    const allowed = ALLOWED_TRANSITIONS[task.status.toLowerCase()]?.[newStatus.toLowerCase()];
    if (!allowed) throw new ValidationError('Invalid status transition');
    
    if (!allowed.roles.includes(userRole)) {
      // Per PRD, wait, let's allow Admin for fallback, but PRD says specifically:
      // draft -> in_progress: Auditor or Manager
      // in_progress -> review: Auditor
      // review -> approved: Manager only
      // review -> in_progress: Manager (reject)
      // approved -> completed: Manager
      throw new ForbiddenError('IAMS-PERM-001');
    }

    // in_progress -> review: block on open critical/high findings
    if (newStatus === 'review') {
      const blocking = await database.prepare(`
        SELECT id FROM audit_findings 
        WHERE audit_id = ? AND status = 'open' 
        AND risk_level IN ('critical', 'high')
      `).all(task.plan_id); // Assuming findings are linked to plan_id. Wait, PRD 3.1 snippet:
      // WHERE audit_id = ? AND status = 'open'
      // ).all(taskId);
      // Wait, is it audit_id = taskId? The PRD snippet says:
      // `SELECT id FROM audit_findings WHERE audit_id = ? ... `.all(taskId)
      // I will use `taskId` directly, wait! finding has `audit_id` which might be `audit_plans.id`. Wait, in PRD 3.1: `.all(taskId);`
      
      // Let's use exactly what PRD provided:
      const blocking2 = await database.prepare(`
        SELECT id FROM audit_findings 
        WHERE audit_id = ? AND status = 'open' 
        AND risk_level IN ('critical', 'high')
      `).all(taskId);
      
      if (blocking2.length > 0)
        throw new ValidationError('Open critical findings block this transition');
    }

    // review -> approved: block if any recommendation lacks an action plan
    if (newStatus === 'approved') {
      const incomplete = await database.prepare(`
        SELECT r.id FROM recommendations r
        JOIN audit_findings f ON r.finding_id = f.id
        WHERE f.audit_id = ? 
        AND (r.action_plan IS NULL OR r.action_plan = '' OR r.due_date IS NULL)
      `).all(taskId);
      
      if (incomplete.length > 0)
        throw new ValidationError('All recommendations must have an action plan and due date');
    }

    await database.prepare(
      'UPDATE audit_tasks SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
    ).run(newStatus, taskId);
  }
}
