import { db } from '../db/index';
import { BaseService } from './BaseService';
import { NotificationService } from './NotificationService';

export class AuditPlanService extends BaseService {
  static async generatePlanCode(): Promise<string> {
    const currentYear = new Date().getFullYear();
    const prefix = `AP-${currentYear}-`;
    
    try {
      // Find the latest plan code for the current year
      const latestPlan = await db.prepare(
        `SELECT plan_code FROM audit_plans 
         WHERE plan_code LIKE ? 
         ORDER BY plan_code DESC LIMIT 1`
      ).get(`${prefix}%`) as any;

      let nextNumber = 1;
      if (latestPlan && latestPlan.plan_code) {
        const parts = latestPlan.plan_code.split('-');
        const lastNumber = parseInt(parts[parts.length - 1]);
        if (!isNaN(lastNumber)) {
          nextNumber = lastNumber + 1;
        }
      }

      // Format with leading zeros (e.g., 001)
      const formattedNumber = nextNumber.toString().padStart(3, '0');
      const newCode = `${prefix}${formattedNumber}`;
      return newCode;
    } catch (error) {
      console.error('[AuditPlanService] Error generating plan code:', error);
      // Fallback to a timestamp-based code if something fails to avoid blocking creation
      return `${prefix}ERR-${Date.now().toString().slice(-3)}`;
    }
  }

  static async create(tableName: string, data: any) {
    const planCode = await this.generatePlanCode();
    const body = { ...data, plan_code: planCode };
    return super.create(tableName, body);
  }

  static async update(tableName: string, id: string | number, data: any) {
    // Get the current status before update
    const currentPlan = await db.prepare("SELECT status, title, lead_auditor FROM audit_plans WHERE id = ?").get(id) as any;
    
    const result = await super.update(tableName, id, data);

    // --- AUTOMATION: Auto-generate report when audit plan is completed ---
    if (data.status === 'Completed' || data.status === 'Closed') {
      if (currentPlan && currentPlan.status !== data.status) {
        try {
          // Check if a report already exists for this audit
          const existingReport = await db.prepare("SELECT id FROM audit_reports WHERE audit_id = ?").get(id);
          
          if (!existingReport) {
            // Generate a new report
            const reportTitle = `Final Audit Report: ${data.title || currentPlan.title}`;
            const reportSummary = `This is an automatically generated final report for the audit engagement: ${data.title || currentPlan.title}. The audit has been marked as ${data.status}.`;
            
            await db.prepare(`
              INSERT INTO audit_reports (title, type, audit_id, summary, findings_included, status, created_by) 
              VALUES (?, ?, ?, ?, ?, ?, ?)
            `).run(reportTitle, 'Audit Report', id, reportSummary, 1, 'Final', 'System');

            await this.logAudit('System', `Auto-generated final report for Audit ID: ${id}`, "audit_reports", JSON.stringify({ title: reportTitle }));

            // Notify the lead auditor
            const leadAuditor = data.lead_auditor || currentPlan.lead_auditor;
            if (leadAuditor) {
              const user = await db.prepare("SELECT id FROM users WHERE name = ? OR username = ?").get(leadAuditor, leadAuditor) as any;
              if (user) {
                await NotificationService.create(
                  user.id,
                  'Report Auto-Generated',
                  `The final audit report for "${data.title || currentPlan.title}" has been automatically generated.`,
                  'audit_reports',
                  '/reports'
                );
              }
            }
          }
        } catch (err: any) {
          console.error('[Automation Error] Failed to auto-generate report:', err);
          
          try {
            // Un-silence the error by escalating it to the system error logs for Administrator visibility
            await db.prepare(`
              INSERT INTO system_error_log (user_id, action, current_route, error_message, stack_trace, user_agent, ip_address, status)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            `).run(
              null, "Auto-Generate Report", "AuditPlanService.update", 
              err?.message || "Unknown error generating report", err?.stack || "", 
              "System_Job", "127.0.0.1", "Unresolved"
            );
          } catch (loggingErr) {
            console.error("Critical failure writing to system_error_log", loggingErr);
          }
        }
      }
    }
    // ------------------------------------------------------------------------

    return result;
  }
}
