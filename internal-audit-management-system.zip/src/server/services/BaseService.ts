import { db } from '../db/index';
import { NotFoundError, ValidationError } from '../utils/errors';

export class BaseService {
  protected static db = db;

  static async logAudit(username: string, action: string, module: string, details: string) {
    try {
      await this.db.prepare("INSERT INTO audit_trail (user, action, module, details) VALUES (?::text, ?::text, ?::text, ?::text)")
        .run(username, action, module, details);
    } catch (error) {
      console.error("[System Log Error] Failed to insert audit trail:", error);
    }
  }

  protected static sanitizeBody(body: any) {
    const sanitized = { ...body };
    Object.keys(sanitized).forEach(key => {
      // Convert empty strings to null for fields that are likely UUIDs or foreign keys
      if (sanitized[key] === "" && (key.endsWith('_id') || key === 'id' || key.includes('uuid'))) {
        sanitized[key] = null;
      }
    });
    return sanitized;
  }

  static async findAll(tableName: string, options: { page?: number; pageSize?: number; orderBy?: string; where?: Record<string, any>; select?: string[] } = {}) {
    const { page = 1, pageSize = 10, orderBy = 'id DESC', where = {}, select } = options;
    const offset = (page - 1) * pageSize;

    const validatedTable = this.db.validateIdentifier(tableName);
    
    // Validate orderBy to prevent SQL injection
    const orderParts = (orderBy || 'id').trim().split(/\s+/);
    const orderColumn = orderParts[0] || 'id';
    const orderDirection = (orderParts[1] || 'DESC').toUpperCase();
    
    // Strict regex for column name
    if (orderColumn && !/^[a-zA-Z0-9_]+$/.test(orderColumn)) {
      throw new ValidationError(`Invalid orderBy column name: ${orderColumn}`);
    }
    // Strict match for direction
    if (orderDirection !== 'ASC' && orderDirection !== 'DESC') {
      throw new ValidationError(`Invalid orderBy direction: ${orderDirection}`);
    }
    // Final safe orderBy string
    const safeOrderBy = `${orderColumn} ${orderDirection}`;

    // Safe select columns
    const safeSelect = select && select.length > 0
      ? select.filter(s => /^[a-zA-Z0-9_]+$/.test(s)).join(', ')
      : '*';

    let whereClause = '';
    const whereValues: any[] = [];
    const whereKeys = Object.keys(where);
    
    if (whereKeys.length > 0) {
      whereClause = 'WHERE ' + whereKeys.map((key, i) => `${this.db.validateIdentifier(key)} = ?`).join(' AND ');
      whereValues.push(...Object.values(where));
    }

    const countRes = await this.db.prepare(`SELECT COUNT(*) as total FROM ${validatedTable} ${whereClause}`).get(...whereValues);
    const total = countRes?.total || 0;

    const query = `SELECT ${safeSelect} FROM ${validatedTable} ${whereClause} ORDER BY ${safeOrderBy} LIMIT ? OFFSET ?`;
    const data = await this.db.prepare(query).all(...whereValues, pageSize, offset);

    return {
      data,
      pagination: {
        page,
        pageSize,
        total,
        totalPages: Math.ceil(total / pageSize)
      }
    };
  }

  static async findById(tableName: string, id: string | number) {
    const validatedTable = this.db.validateIdentifier(tableName);
    const item = await this.db.prepare(`SELECT * FROM ${validatedTable} WHERE id = ?`).get(id);
    if (!item) {
      throw new NotFoundError(`${tableName} item with ID ${id} not found`);
    }
    return item;
  }

  static async create(tableName: string, data: any) {
    const body = this.sanitizeBody(data);
    // Only delete internal fields, ensure plan_code stays if provided
    const restrictedColumns = ['id', 'created_at', 'updated_at'];
    restrictedColumns.forEach(col => {
      if (col in body) delete body[col];
    });

    const keys = Object.keys(body).map(k => this.db.validateIdentifier(k));
    const values = Object.values(body);

    if (keys.length === 0) {
      throw new ValidationError("No data provided for creation");
    }

    const placeholders = keys.map(() => "?").join(",");
    const validatedTable = this.db.validateIdentifier(tableName);
    const stmt = await this.db.prepare(`INSERT INTO ${validatedTable} (${keys.join(",")}) VALUES (${placeholders})`);
    const info = await stmt.run(...values);

    return { id: info.lastInsertRowid, ...body };
  }

  static async update(tableName: string, id: string | number, data: any) {
    const body = this.sanitizeBody(data);
    const restrictedColumns = ['id', 'created_at', 'updated_at'];
    restrictedColumns.forEach(col => delete body[col]);

    const keys = Object.keys(body).map(k => this.db.validateIdentifier(k));
    const values = Object.values(body);

    if (keys.length === 0) {
      throw new ValidationError("No data provided for update");
    }

    const setClause = keys.map(k => `${k} = ?`).join(",");
    const validatedTable = this.db.validateIdentifier(tableName);
    const updatedRow = await this.db.prepare(`UPDATE ${validatedTable} SET ${setClause} WHERE id = ? RETURNING id`).get(...values, id);

    if (!updatedRow) {
      throw new NotFoundError(`${tableName} item with ID ${id} not found`);
    }

    return { id, ...body };
  }

  static async delete(tableName: string, id: string | number) {
    const validatedTable = this.db.validateIdentifier(tableName);
    await this.db.prepare(`DELETE FROM ${validatedTable} WHERE id = ?`).run(id);
    return true;
  }
}
