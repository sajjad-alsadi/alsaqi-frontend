import { db } from '../db/index';
import { ValidationError } from '../utils/errors';

export class AuditService {
  static async getFindings() {
    return await db.prepare("SELECT * FROM audit_findings").all();
  }

  static async createFinding(body: any) {
    const keys = Object.keys(body).map(k => db.validateIdentifier(k));
    const values = Object.values(body);
    
    if (keys.length === 0) {
      throw new ValidationError("No data provided");
    }

    const placeholders = keys.map(() => "?").join(",");
    const stmt = db.prepare(`INSERT INTO audit_findings (${keys.join(",")}) VALUES (${placeholders})`);
    const info = await stmt.run(...values);
    const findingId = info.lastInsertRowid;

    // Automatically create a recommendation
    const plan = await db.prepare("SELECT department FROM audit_plans WHERE id = ?").get(body.audit_id) as any;
    const department = plan ? plan.department : 'Unknown';
    
    await db.prepare(`INSERT INTO recommendations (finding_id, department, responsible, due_date, status, risk_level) 
                VALUES (?, ?, ?, ?, ?, ?)`)
      .run(findingId, department, 'TBD', '', 'Pending', body.risk_level || 'Medium');

    return findingId;
  }

  static async updateFinding(id: string, body: any) {
    const data = { ...body };
    delete data.id;

    const keys = Object.keys(data).map(k => db.validateIdentifier(k));
    const values = Object.values(data);
    
    if (keys.length === 0) {
      throw new ValidationError("No data provided for update");
    }

    const setClause = keys.map(k => `${k} = ?`).join(",");
    await db.prepare(`UPDATE audit_findings SET ${setClause} WHERE id = ?`).run(...values, id);

    // Sync risk level to recommendation
    if (data.risk_level) {
      await db.prepare("UPDATE recommendations SET risk_level = ? WHERE finding_id = ?").run(data.risk_level, id);
    }
  }

  static async deleteFinding(id: string) {
    await db.prepare("DELETE FROM recommendations WHERE finding_id = ?").run(id);
    await db.prepare("DELETE FROM audit_findings WHERE id = ?").run(id);
  }
}
