import { db } from '../db/index';
import { NotFoundError } from '../utils/errors';

export class RoleService {
  static async getAllRoles() {
    const roles = await db.prepare("SELECT * FROM roles ORDER BY name ASC").all() as any[];
    
    const rolesWithPermissions = await Promise.all(roles.map(async (role) => {
      const permissions = await db.prepare(`
        SELECT p.id, p.module, p.action
        FROM permissions p
        JOIN role_permissions rp ON p.id = rp.permission_id
        WHERE rp.role_id = ?
      `).all(role.id);
      return { ...role, permissions };
    }));

    return rolesWithPermissions;
  }

  static async getRolePermissions(roleId: string | number) {
    const perms = await db.prepare(`
      SELECT p.* 
      FROM permissions p
      JOIN role_permissions rp ON p.id = rp.permission_id
      WHERE rp.role_id = ?
    `).all(roleId);
    return perms;
  }

  static async updateRolePermissions(roleId: string | number, permissionIds: (string | number)[]) {
    const uniquePermissionIds = Array.isArray(permissionIds) ? [...new Set(permissionIds)] : [];
    
    const transaction = db.transaction(async () => {
      await db.prepare("DELETE FROM role_permissions WHERE role_id = ?::uuid").run(roleId);
      for (const pid of uniquePermissionIds) {
        await db.prepare("INSERT INTO role_permissions (role_id, permission_id) VALUES (?::uuid, ?::uuid) ON CONFLICT DO NOTHING").run(roleId, pid);
      }
    });
    await transaction();
    return true;
  }

  static async getAllPermissions() {
    return await db.prepare("SELECT * FROM permissions ORDER BY module ASC, action ASC").all();
  }
}
