import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { db } from '../db/index';
import { AuthError, ForbiddenError } from '../utils/errors';

export class AuthService {
  static async login(usernameOrEmail: string, password: string, jwtSecret: string, JWT_PRIVATE_KEY: string, ipAddress?: string, userAgent?: string) {
    return await db.transaction(async () => {
      // Support login by username or email, case-insensitive
      const user = await db.prepare(`
        SELECT * FROM users 
        WHERE LOWER(username) = LOWER(?::text) OR LOWER(email) = LOWER(?::text)
      `).get(usernameOrEmail, usernameOrEmail) as any;
      
      if (!user) {
        console.warn(`[AuthService] Login failed: User not found for "${usernameOrEmail}"`);
        throw new AuthError("Invalid credentials");
      }

      if (user.status === 'Suspended') {
        console.warn(`[AuthService] Login failed: Account suspended for "${user.username}"`);
        throw new ForbiddenError("Account suspended");
      }

      if (user.locked_until && new Date(user.locked_until) > new Date()) {
        console.warn(`[AuthService] Login failed: Account locked for "${user.username}"`);
        throw new ForbiddenError("Account locked");
      }

      if (!bcrypt.compareSync(password, user.password)) {
        console.warn(`[AuthService] Login failed: Invalid password for "${user.username}"`);
        await db.prepare("UPDATE users SET failed_attempts = failed_attempts + 1 WHERE id = ?::uuid").run(user.id);
        if (user.failed_attempts + 1 >= 5) {
          await db.prepare("UPDATE users SET locked_until = ?::timestamp WHERE id = ?::uuid").run(new Date(Date.now() + 15 * 60 * 1000).toISOString(), user.id);
        }
        throw new AuthError("Invalid credentials");
      }

      await db.prepare("UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login = CURRENT_TIMESTAMP WHERE id = ?::uuid").run(user.id);

      // Log login history
      try {
        await db.prepare("INSERT INTO login_history (user_id, ip_address, user_agent, status) VALUES (?::uuid, ?::text, ?::text, 'Success')")
          .run(user.id, ipAddress || 'Unknown', userAgent || 'Unknown');
      } catch (e) {
        console.error("[AuthService] Failed to log login history", e);
      }

      console.log("JWT_PRIVATE_KEY is a", typeof JWT_PRIVATE_KEY, "starting with:", typeof JWT_PRIVATE_KEY === "string" ? JWT_PRIVATE_KEY.substring(0, 30).replace(/\n/g, '\\n') : JWT_PRIVATE_KEY);
      const token = jwt.sign(
        { id: user.id, username: user.username, role: user.role, session_version: user.session_version },
        JWT_PRIVATE_KEY,
        { algorithm: 'RS256', expiresIn: '15m' }
      );

      const refreshToken = jwt.sign(
        { id: user.id, username: user.username, role: user.role, session_version: user.session_version },
        JWT_PRIVATE_KEY,
        { algorithm: 'RS256', expiresIn: '8h' }
      );
      const sessionToken = crypto.randomBytes(64).toString('hex');
      
      const refreshExpiry = new Date(Date.now() + 8 * 60 * 60 * 1000); // 8 hours
      // Insert into refresh_tokens for compatibility
      await db.prepare("INSERT INTO refresh_tokens (token, user_id, expires_at) VALUES (?::text, ?::uuid, ?::timestamp)").run(refreshToken, user.id, refreshExpiry.toISOString());
      
      // Insert into user_sessions for session management
      try {
        await db.prepare(`
          INSERT INTO user_sessions (user_id, session_token, refresh_token, ip_address, browser, status)
          VALUES (?::uuid, ?::text, ?::text, ?::text, ?::text, 'Active')
        `).run(user.id, sessionToken, refreshToken, ipAddress || 'Unknown', userAgent || 'Unknown');
      } catch (e) {
        console.error("[AuthService] Failed to create user session", e);
      }

      return {
        user: {
          id: user.id,
          username: user.username,
          role: user.role,
          name: user.name,
          requires_password_change: user.requires_password_change
        },
        token,
        refreshToken
      };
    })();
  }

  static async logAudit(username: string, action: string, module: string, details: string) {
    await db.prepare("INSERT INTO audit_trail (user, action, module, details) VALUES (?::text, ?::text, ?::text, ?::text)")
      .run(username, action, module, details);
  }
}
