import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, Search, Filter, Plus, Edit2, Trash2, Eye, 
  Download, FileText, CheckCircle, AlertTriangle, XCircle, AlertCircle
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import api from '../services/api';
import Modal from '../components/Modal';
import { useDepartments } from '../hooks/useDepartments';

// --- Types ---
type ComplianceStatus = 'compliant' | 'partial' | 'non_compliant' | 'under_review';
type SourceType = 'cbi_instruction' | 'law' | 'internal_policy' | 'admin_decision';

interface ComplianceItem {
  id: string;
  ref_number: string;
  title: string;
  source_type: SourceType;
  issuing_authority?: string | null;
  category?: string | null;
  issue_date?: string | null;
  effective_date?: string | null;
  review_date?: string | null;
  compliance_status: ComplianceStatus;
  maturity_score?: number | null;
  gap_notes?: string | null;
  responsible_person_id?: string | null;
  responsible_person_name?: string | null;
  department_id?: string | null;
  department_name?: string | null;
  description?: string | null;
  keywords?: string | null;
  version?: string | null;
  attachment_path?: string | null;
  open_findings_count?: number;
}

const statusColors: Record<ComplianceStatus, { bg: string, text: string, icon: React.ReactNode }> = {
  compliant: { bg: '#D5F5E3', text: '#1D8348', icon: <CheckCircle size={14} className="mr-1" /> },
  partial: { bg: '#FDEBD0', text: '#D68910', icon: <AlertTriangle size={14} className="mr-1" /> },
  non_compliant: { bg: '#FADBD8', text: '#CB4335', icon: <XCircle size={14} className="mr-1" /> },
  under_review: { bg: '#E5E7EB', text: '#4B5563', icon: <AlertCircle size={14} className="mr-1" /> },
};

const statusLabelsAR: Record<ComplianceStatus, string> = {
  compliant: 'ملتزم',
  partial: 'جزئي',
  non_compliant: 'غير ملتزم',
  under_review: 'قيد المراجعة',
};

const sourceColors: Record<SourceType, string> = {
  cbi_instruction: 'bg-blue-100 text-blue-800',
  law: 'bg-purple-100 text-purple-800',
  internal_policy: 'bg-teal-100 text-teal-800',
  admin_decision: 'bg-orange-100 text-orange-800',
};

const sourceLabelsAR: Record<SourceType, string> = {
  cbi_instruction: 'تعليمة CBI',
  law: 'قانون',
  internal_policy: 'سياسة داخلية',
  admin_decision: 'قرار إداري',
};

export default function ComplianceMatrix() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState<'registry'|'matrix'|'dashboard'>('registry');
  const [items, setItems] = useState<ComplianceItem[]>([]);
  const [summary, setSummary] = useState<any>(null);
  
  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<ComplianceItem | null>(null);
  const [formData, setFormData] = useState<Partial<ComplianceItem>>({ compliance_status: 'under_review' });

  // Filters
  const [search, setSearch] = useState('');
  const [filterSource, setFilterSource] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  // Dropdown data
  const [users, setUsers] = useState<any[]>([]);
  const { departments } = useDepartments();

  useEffect(() => {
    fetchItems();
    fetchSummary();
  }, [filterSource, filterStatus, search]);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchItems = async () => {
    try {
      const q = new URLSearchParams();
      if (search) q.append('search', search);
      if (filterSource) q.append('source_type', filterSource);
      if (filterStatus) q.append('compliance_status', filterStatus);
      const res = await api.get('/compliance?' + q.toString());
      if (res.data.success) setItems(res.data.data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchSummary = async () => {
    try {
      const res = await api.get('/compliance/summary');
      if (res.data.success) setSummary(res.data.data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchUsers = async () => {
    try {
      const uRes = await api.get('/users/summary');
      if (uRes.data?.success) setUsers(uRes.data.data);
      else {
        const uResFallback = await api.get('/users');
        if (uResFallback.data?.success) setUsers(uResFallback.data.data);
      }
    } catch (e) {}
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (selectedItem?.id) {
        await api.put('/compliance/' + selectedItem.id, formData);
      } else {
        await api.post('/compliance', formData);
      }
      setIsModalOpen(false);
      fetchItems();
      fetchSummary();
    } catch (err) {
      console.error(err);
      alert('Error saving data');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure?')) return;
    try {
      await api.delete('/compliance/' + id);
      fetchItems();
      fetchSummary();
    } catch (e) {
      console.error(e);
    }
  };

  const updateStatus = async (id: string, status: string) => {
    try {
      await api.patch('/compliance/' + id + '/status', { compliance_status: status });
      fetchItems();
      fetchSummary();
    } catch (e) {
      console.error(e);
    }
  };

  const renderBadge = (item: ComplianceItem) => {
    const sourceLabel = sourceLabelsAR[item.source_type] || item.source_type;
    const sourceColor = sourceColors[item.source_type] || 'bg-gray-100 text-gray-800';
    return <span className={`px-2 py-1 text-xs font-medium rounded-full ${sourceColor}`}>{sourceLabel}</span>;
  };

  const renderStatus = (item: ComplianceItem) => {
    const st = statusColors[item.compliance_status];
    const lbl = statusLabelsAR[item.compliance_status];
    return (
      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium" style={{ backgroundColor: st.bg, color: st.text }}>
        {st.icon} {lbl}
      </span>
    );
  };

  // --- RENDERS ---
  const renderRegistry = () => (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="flex rounded-md shadow-sm w-full sm:w-auto overflow-hidden">
          <input 
            type="text" placeholder="بحث..." 
            className="flex-1 w-full sm:w-64 border-gray-300 px-4 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500"
            value={search} onChange={e => setSearch(e.target.value)}
          />
          <span className="inline-flex items-center px-3 rounded-l-md border border-l-0 border-gray-300 bg-gray-50 text-gray-500">
            <Search size={16} />
          </span>
        </div>
        
        <div className="flex gap-2 w-full sm:w-auto">
          <select className="input-field py-2 flex-1 sm:flex-none" value={filterSource} onChange={e => setFilterSource(e.target.value)}>
            <option value="">جميع المصادر</option>
            {Object.entries(sourceLabelsAR).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <select className="input-field py-2 flex-1 sm:flex-none" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
            <option value="">جميع الحالات</option>
            {Object.entries(statusLabelsAR).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <button className="btn-primary flex items-center justify-center gap-2 whitespace-nowrap" onClick={() => { setSelectedItem(null); setFormData({ compliance_status: 'under_review' }); setIsModalOpen(true); }}>
            <Plus size={16} /> إضافة
          </button>
        </div>
      </div>

      <div className="bg-white shadow overflow-auto rounded-lg">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">المرجع</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">العنوان</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">المصدر</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">الحالة</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">المسؤول</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">تاريخ المراجعة</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider text-center">ملاحظات مفتوحة</th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">إجراءات</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {items.map(item => (
              <tr key={item.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.ref_number}</td>
                <td className="px-6 py-4 text-sm text-gray-500 truncate max-w-xs" title={item.title}>{item.title}</td>
                <td className="px-6 py-4 whitespace-nowrap">{renderBadge(item)}</td>
                <td className="px-6 py-4 whitespace-nowrap">{renderStatus(item)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.responsible_person_name || '-'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {item.review_date} 
                  {item.review_date && new Date(item.review_date) < new Date() && <span className="text-red-500 mr-2" title="Overdue">⚠️</span>}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-center">
                  {item.open_findings_count ? <span className="bg-red-100 text-red-800 font-bold px-2 py-1 rounded">{item.open_findings_count}</span> : '-'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-medium flex justify-center gap-2">
                  <button onClick={() => { setSelectedItem(item); setFormData(item); setIsViewModalOpen(true); }} className="text-gray-400 hover:text-gray-900" title="عرض"><Eye size={18} /></button>
                  <button onClick={() => { setSelectedItem(item); setFormData(item); setIsModalOpen(true); }} className="text-emerald-600 hover:text-emerald-900" title="تعديل"><Edit2 size={18} /></button>
                  <select 
                    className="text-xs border-gray-300 rounded p-1"
                    value=""
                    onChange={(e) => {
                      if(e.target.value) updateStatus(item.id, e.target.value);
                    }}
                  >
                    <option value="" disabled>تغيير الحالة</option>
                    {Object.entries(statusLabelsAR).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
                  </select>
                  <button onClick={() => handleDelete(item.id)} className="text-red-600 hover:text-red-900" title="حذف"><Trash2 size={18} /></button>
                </td>
              </tr>
            ))}
            {items.length === 0 && <tr><td colSpan={8} className="px-6 py-12 text-center text-gray-500">لا توجد بيانات</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderMatrix = () => {
    // Pivot table rows = items, columns = status
    const getStatusItems = (status: ComplianceStatus) => items.filter(i => i.compliance_status === status);
    
    return (
      <div className="space-y-4">
        <div className="flex justify-end gap-2">
           <button className="btn-secondary flex items-center gap-2" onClick={() => window.print()}><Download size={16}/> تصدير PDF</button>
           <button className="btn-secondary flex items-center gap-2" onClick={() => alert('Excel export feature not implemented yet')}><FileText size={16}/> تصدير Excel</button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {(['compliant', 'partial', 'non_compliant', 'under_review'] as ComplianceStatus[]).map(status => {
            const stItems = getStatusItems(status);
            const st = statusColors[status];
            const lbl = statusLabelsAR[status];
            return (
              <div key={status} className="border rounded-lg shadow-sm" style={{ backgroundColor: st.bg + '30', borderColor: st.bg }}>
                <div className="p-3 border-b font-medium flex justify-between items-center" style={{ backgroundColor: st.bg, color: st.text }}>
                  <div className="flex items-center gap-2">{st.icon} {lbl}</div>
                  <div className="bg-white px-2 py-0.5 rounded-full text-xs font-bold">{stItems.length}</div>
                </div>
                <div className="p-2 space-y-2 max-h-96 overflow-y-auto">
                  {stItems.map(item => (
                    <div key={item.id} className="bg-white p-2 rounded border border-gray-100 shadow-sm text-sm cursor-pointer hover:shadow" onClick={() => { setSelectedItem(item); setFormData(item); setIsViewModalOpen(true); }}>
                      <div className="font-semibold text-gray-800 text-xs mb-1">{item.ref_number}</div>
                      <div className="text-gray-600 truncate" title={item.title}>{item.title}</div>
                      <div className="mt-2">{renderBadge(item)}</div>
                    </div>
                  ))}
                  {stItems.length === 0 && <div className="text-center text-gray-400 text-sm py-4">فارغ</div>}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const renderDashboard = () => {
    var countsByStatus = summary?.counts || [];
    var total = countsByStatus.reduce((acc: number, c: any) => acc + c.count, 0);
    const getCount = (st: string) => countsByStatus.find((c: any) => c.compliance_status === st)?.count || 0;
    
    const overdueItems = items.filter(i => i.review_date && new Date(i.review_date) < new Date()).sort((a,b) => new Date(a.review_date!).getTime() - new Date(b.review_date!).getTime());

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="bg-white p-4 rounded-lg shadow border-b-4 border-blue-500">
            <div className="text-sm text-gray-500 font-medium">إجمالي العناصر</div>
            <div className="text-3xl font-bold text-gray-900 mt-2">{total}</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow border-b-4 border-green-500">
            <div className="text-sm text-gray-500 font-medium">ملتزم</div>
            <div className="text-3xl font-bold text-green-600 mt-2">{getCount('compliant')}</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow border-b-4 border-red-500">
            <div className="text-sm text-gray-500 font-medium">غير ملتزم</div>
            <div className="text-3xl font-bold text-red-600 mt-2">{getCount('non_compliant')}</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow border-b-4 border-orange-500">
            <div className="text-sm text-gray-500 font-medium">مراجعة متأخرة</div>
            <div className="text-3xl font-bold text-orange-600 mt-2">{summary?.overdueReview || 0}</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow border-b-4 border-yellow-500">
            <div className="text-sm text-gray-500 font-medium">استحقاق خلال 30 يوم</div>
            <div className="text-3xl font-bold text-yellow-600 mt-2">{summary?.dueSoon || 0}</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-medium text-gray-900 mb-4">العناصر المتأخرة عن المراجعة</h3>
              <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                {overdueItems.map(item => (
                  <div key={item.id} className="flex justify-between items-center p-3 bg-red-50 border border-red-100 rounded-lg">
                    <div>
                      <div className="font-medium text-red-800">{item.ref_number}</div>
                      <div className="text-sm text-red-600 truncate max-w-[200px]" title={item.title}>{item.title}</div>
                    </div>
                    <div className="text-right">
                       <span className="text-xs bg-red-200 text-red-800 px-2 py-1 rounded font-bold">{item.review_date}</span>
                       <div className="text-xs text-gray-500 mt-1">{item.responsible_person_name || 'غير محدد'}</div>
                    </div>
                  </div>
                ))}
                {overdueItems.length === 0 && <div className="text-gray-500 text-center py-4">لا توجد عناصر متأخرة</div>}
              </div>
           </div>
           
           <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-medium text-gray-900 mb-4">التوزيع حسب النوع</h3>
              <div className="space-y-4">
                {(Object.entries(sourceLabelsAR) as [SourceType, string][]).map(([type, label]) => {
                  const count = items.filter(i => i.source_type === type).length;
                  const pct = total === 0 ? 0 : Math.round((count / total) * 100);
                  const colorClass = sourceColors[type].split(' ')[0].replace('bg-', 'bg-');
                  return (
                    <div key={type}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="font-medium text-gray-700">{label}</span>
                        <span className="text-gray-500">{count} ({pct}%)</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className={`h-2.5 rounded-full ${colorClass.replace('100', '500')}`} style={{ width: `${pct}%` }}></div>
                      </div>
                    </div>
                  );
                })}
              </div>
           </div>
        </div>
      </div>
    );
  };

  return (
    <div className="p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="bg-emerald-100 p-3 rounded-lg">
          <ShieldCheck className="text-emerald-600" size={24} />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">مصفوفة الامتثال</h1>
          <p className="text-gray-500">إدارة المطابقة والتوافق مع القوانين والأنظمة</p>
        </div>
      </div>

      <div className="mb-6 border-b border-gray-200">
        <nav className="flex space-x-8 space-x-reverse">
          <button 
            onClick={() => setActiveTab('registry')}
            className={`whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'registry' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
          >السجل</button>
          <button 
            onClick={() => setActiveTab('matrix')}
            className={`whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'matrix' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
          >مصفوفة الفجوات</button>
          <button 
            onClick={() => setActiveTab('dashboard')}
            className={`whitespace-nowrap pb-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'dashboard' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
          >المؤشرات</button>
        </nav>
      </div>

      {activeTab === 'registry' && renderRegistry()}
      {activeTab === 'matrix' && renderMatrix()}
      {activeTab === 'dashboard' && renderDashboard()}

      {/* Write/Edit Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={selectedItem ? "تعديل السجل" : "سجل جديد"}>
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">الرقم المرجعي *</label>
              <input type="text" required className="input-field" value={formData.ref_number || ''} onChange={e => setFormData({...formData, ref_number: e.target.value})} />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">العنوان *</label>
              <input type="text" required className="input-field" value={formData.title || ''} onChange={e => setFormData({...formData, title: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">النوع / المصدر *</label>
              <select required className="input-field" value={formData.source_type || ''} onChange={e => setFormData({...formData, source_type: e.target.value as SourceType})}>
                <option value="">اختيار</option>
                {Object.entries(sourceLabelsAR).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">الجهة المصدرة</label>
              <input type="text" className="input-field" value={formData.issuing_authority || ''} onChange={e => setFormData({...formData, issuing_authority: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">التصنيف</label>
              <input type="text" className="input-field" value={formData.category || ''} onChange={e => setFormData({...formData, category: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">تاريخ الإصدار</label>
              <input type="date" className="input-field" value={formData.issue_date || ''} onChange={e => setFormData({...formData, issue_date: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">تاريخ النفاذ</label>
              <input type="date" className="input-field" value={formData.effective_date || ''} onChange={e => setFormData({...formData, effective_date: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">تاريخ المراجعة القادمة</label>
              <input type="date" className="input-field" value={formData.review_date || ''} onChange={e => setFormData({...formData, review_date: e.target.value})} />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">حالة الامتثال</label>
              <select className="input-field" value={formData.compliance_status || 'under_review'} onChange={e => setFormData({...formData, compliance_status: e.target.value as ComplianceStatus})}>
                {Object.entries(statusLabelsAR).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">درجة النضج (0-100)</label>
              <input type="number" min="0" max="100" className="input-field" value={formData.maturity_score || ''} onChange={e => setFormData({...formData, maturity_score: parseInt(e.target.value)})} />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">الشخص المسؤول</label>
              <select className="input-field" value={formData.responsible_person_id || ''} onChange={e => setFormData({...formData, responsible_person_id: e.target.value})}>
                <option value="">اختيار شخص</option>
                {users.map(u => <option key={u.id} value={u.id}>{u.name || u.full_name || u.username}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">الدائرة / القسم</label>
              <select className="input-field" value={formData.department_id || ''} onChange={e => setFormData({...formData, department_id: e.target.value})}>
                <option value="">اختيار القسم</option>
                {departments.map(d => <option key={d.id} value={d.id}>{d.name_ar || d.name_en || d.name}</option>)}
              </select>
            </div>
            
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">ملاحظات الفجوة / الإجراءات المطلوبة</label>
              <textarea className="input-field" rows={2} value={formData.gap_notes || ''} onChange={e => setFormData({...formData, gap_notes: e.target.value})}></textarea>
            </div>

             <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">الوصف</label>
              <textarea className="input-field" rows={3} value={formData.description || ''} onChange={e => setFormData({...formData, description: e.target.value})}></textarea>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">الكلمات الدالة</label>
              <input type="text" className="input-field" value={formData.keywords || ''} onChange={e => setFormData({...formData, keywords: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">الإصدار</label>
              <input type="text" className="input-field" value={formData.version || ''} onChange={e => setFormData({...formData, version: e.target.value})} />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">مسار الاستمارة المرفقة (رابط / ملف)</label>
              <input type="text" className="input-field" value={formData.attachment_path || ''} onChange={e => setFormData({...formData, attachment_path: e.target.value})} />
            </div>
          </div>
          
          <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-gray-200">
            <button type="button" onClick={() => setIsModalOpen(false)} className="btn-secondary">إلغاء</button>
            <button type="submit" className="btn-primary">حفظ</button>
          </div>
        </form>
      </Modal>

      {/* View Modal */}
      <Modal isOpen={isViewModalOpen} onClose={() => setIsViewModalOpen(false)} title="تفاصيل السجل">
        {selectedItem && (
          <div className="space-y-6">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-xl font-bold text-gray-900">{selectedItem.title}</h2>
                <div className="text-sm text-gray-500 mt-1">الرقم المرجعي: {selectedItem.ref_number}</div>
              </div>
              <div>{renderBadge(selectedItem)}</div>
            </div>

            <div className="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded-lg">
              <div>
                <div className="text-sm text-gray-500">تاريخ الإصدار</div>
                <div className="font-medium text-gray-900">{selectedItem.issue_date || '-'}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500">تاريخ المراجعة القادمة</div>
                <div className="font-medium text-gray-900">{selectedItem.review_date || '-'}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500">الشخص المسؤول</div>
                <div className="font-medium text-gray-900">{selectedItem.responsible_person_name || '-'}</div>
              </div>
              <div>
                <div className="text-sm text-gray-500">الدائرة المعنية</div>
                <div className="font-medium text-gray-900">{selectedItem.department_name || '-'}</div>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-900 mb-2">الامتثال والمطابقة</h3>
              <div className="bg-white border rounded-lg p-4">
                 <div className="flex items-center justify-between mb-4">
                    <div className="text-sm text-gray-500">حالة التقييم</div>
                    <div>{renderStatus(selectedItem)}</div>
                 </div>
                 {typeof selectedItem.maturity_score === 'number' && (
                   <div className="mb-4">
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-gray-500">درجة النضج</span>
                        <span className="font-bold">{selectedItem.maturity_score}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div className="bg-emerald-600 h-2.5 rounded-full" style={{width: `${selectedItem.maturity_score}%`}}></div>
                      </div>
                   </div>
                 )}
                 {selectedItem.gap_notes && (
                   <div>
                     <div className="text-sm text-gray-500 mb-1">ملاحظات التحسين وفجوة الامتثال</div>
                     <p className="text-sm text-gray-800 bg-orange-50 p-3 rounded">{selectedItem.gap_notes}</p>
                   </div>
                 )}
              </div>
            </div>

            {(selectedItem.description) && (
              <div>
                <h3 className="text-sm font-medium text-gray-900 mb-2">الوصف</h3>
                <p className="text-sm text-gray-600">{selectedItem.description}</p>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
