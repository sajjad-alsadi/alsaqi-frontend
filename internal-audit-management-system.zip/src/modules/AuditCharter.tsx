import React from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { BookOpen, Shield, Users, Target, FileText, CheckCircle, Scale, AlertTriangle, Briefcase, Building } from 'lucide-react';

const AuditCharter: React.FC = () => {
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';

  const charterData = {
    title: t('common.auditCharter'),
    company: t('common.brandName'),
    version: "V2.0",
    date: "28-01-2026",
    sections: [
      {
        id: "intro",
        title: t('charter.intro_title'),
        icon: BookOpen,
        content: t('charter.intro_content', { returnObjects: true }) as string[],
      },
      {
        id: "definitions",
        title: t('charter.definitions_title'),
        icon: FileText,
        items: t('charter.definitions_items', { returnObjects: true }) as { term: string; def: string }[]
      },
      {
        id: "organization",
        title: t('charter.organization_title'),
        icon: Building,
        content: t('charter.organization_content', { returnObjects: true }) as string[]
      },
      {
        id: "purpose",
        title: t('charter.purpose_title'),
        icon: Target,
        content: t('charter.purpose_content', { returnObjects: true }) as string[]
      },
      {
        id: "reports",
        title: t('charter.reports_title'),
        icon: FileText,
        content: t('charter.reports_content', { returnObjects: true }) as string[],
        table: t('charter.reports_table', { returnObjects: true }) as { name: string; freq: string; recipient: string; notes: string }[]
      },
      {
        id: "independence",
        title: t('charter.independence_title'),
        icon: Scale,
        content: t('charter.independence_content', { returnObjects: true }) as string[]
      },
      {
        id: "scope",
        title: t('charter.scope_title'),
        icon: Shield,
        content: t('charter.scope_content', { returnObjects: true }) as string[]
      },
      {
        id: "authorities",
        title: t('charter.authorities_title'),
        icon: Briefcase,
        content: t('charter.authorities_content', { returnObjects: true }) as string[]
      },
      {
        id: "responsibilities",
        title: t('charter.responsibilities_title'),
        icon: Users,
        content: t('charter.responsibilities_content', { returnObjects: true }) as string[]
      },
      {
        id: "manager_responsibilities",
        title: t('charter.manager_responsibilities_title'),
        icon: Target,
        content: t('charter.manager_responsibilities_content', { returnObjects: true }) as string[]
      },
      {
        id: "external_relations",
        title: t('charter.external_relations_title'),
        icon: Building,
        content: t('charter.external_relations_content', { returnObjects: true }) as string[]
      },
      {
        id: "references",
        title: t('charter.references_title'),
        icon: BookOpen,
        content: t('charter.references_content', { returnObjects: true }) as string[]
      },
      {
        id: "approval",
        title: t('charter.approval_title'),
        icon: CheckCircle,
        content: t('charter.approval_content', { returnObjects: true }) as string[]
      }
    ]
  };

  return (
    <div className="space-y-10">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
        <div>
          <h2 className="text-4xl font-black text-slate-800 tracking-tight">{t('common.auditCharter')}</h2>
          <p className="text-sm text-slate-400 font-bold mt-2">{charterData.company}</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="bg-slate-100 px-4 py-2 rounded-[1.5rem] text-sm font-bold text-slate-600">
            {t('common.version')}: {charterData.version}
          </div>
          <div className="bg-slate-100 px-4 py-2 rounded-[1.5rem] text-sm font-bold text-slate-600">
            {t('common.date')}: {charterData.date}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8">
        {charterData.sections.map((section, idx) => {
          const Icon = section.icon;
          return (
            <motion.div 
              key={section.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="glass-card p-8"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary">
                  <Icon size={24} />
                </div>
                <h3 className="text-2xl font-black text-slate-800">{section.title}</h3>
              </div>
              
              <div className="space-y-4 text-slate-600 leading-relaxed">
                {section.content && section.content.map((p, i) => (
                  <p key={i} className={p.match(/^\d+\./) ? (isRTL ? "pe-4" : "ps-4") : ""}>
                    {p}
                  </p>
                ))}
                
                {section.items && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                    {section.items.map((item, i) => (
                      <div key={i} className="bg-slate-50 p-4 rounded-[1.5rem] border border-slate-100">
                        <h4 className="font-bold text-slate-800 mb-2">{item.term}</h4>
                        <p className="text-sm text-slate-600">{item.def}</p>
                      </div>
                    ))}
                  </div>
                )}

                {section.table && (
                  <div className="overflow-x-auto mt-6">
                    <table className="w-full text-start border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-100">
                          <th className="px-6 py-4 text-xs font-black text-slate-400 uppercase">{t('common.reportName')}</th>
                          <th className="px-6 py-4 text-xs font-black text-slate-400 uppercase">{t('common.frequency')}</th>
                          <th className="px-6 py-4 text-xs font-black text-slate-400 uppercase">{t('common.recipients')}</th>
                          <th className="px-6 py-4 text-xs font-black text-slate-400 uppercase">{t('common.notes')}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {section.table.map((row, i) => (
                          <tr key={i} className="hover:bg-slate-50/50">
                            <td className="px-6 py-4 text-sm font-bold text-slate-700">{row.name}</td>
                            <td className="px-6 py-4 text-sm text-slate-600">{row.freq}</td>
                            <td className="px-6 py-4 text-sm text-slate-600">{row.recipient}</td>
                            <td className="px-6 py-4 text-sm text-slate-500">{row.notes}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

export default AuditCharter;
