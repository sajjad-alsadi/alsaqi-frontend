import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Filter, 
  Plus, 
  Eye, 
  Download, 
  MoreVertical,
  Calendar,
  User,
  Building,
  Tag,
  AlertCircle,
  CheckCircle,
  Clock,
  FileText,
  X,
  Mail
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import api from '../../services/api';
import { motion, AnimatePresence } from 'motion/react';
import Pagination from '../../components/Pagination';
import { useFormat } from '../../services/formatService';
import { useDebounce } from '../../hooks/useDebounce';

import IncomingForm from './IncomingForm';

interface IncomingRegisterProps {
  language: 'ar' | 'en';
  onViewDetails: (id: number) => void;
}

const IncomingRegister: React.FC<IncomingRegisterProps> = ({ language, onViewDetails }) => {
  const { t } = useTranslation();
  const { formatNumber, formatDate } = useFormat();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [pagination, setPagination] = useState({ page: 1, pageSize: 15, total: 0, totalPages: 0 });
  const [filters, setFilters] = useState({
    search: '',
    status: '',
    priority: '',
    dept_id: '',
    start_date: '',
    end_date: ''
  });
  const debouncedSearch = useDebounce(filters.search, 500);
  const [departments, setDepartments] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);

  useEffect(() => {
    fetchData();
  }, [debouncedSearch, filters.status, filters.priority, filters.dept_id, filters.start_date, filters.end_date, pagination.page, pagination.pageSize]);

  useEffect(() => {
    fetchMetadata();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.append('page', pagination.page.toString());
      params.append('pageSize', pagination.pageSize.toString());
      if (debouncedSearch) params.append('search', debouncedSearch);
      if (filters.status) params.append('status', filters.status);
      if (filters.priority) params.append('priority', filters.priority);
      if (filters.dept_id) params.append('dept_id', filters.dept_id);
      if (filters.start_date) params.append('start_date', filters.start_date);
      if (filters.end_date) params.append('end_date', filters.end_date);

      const response = await api.get(`/correspondence/incoming?${params.toString()}`);
      if (response.data.data) {
        setItems(response.data.data);
        setPagination(prev => ({
          ...prev,
          total: response.data.pagination.total,
          totalPages: response.data.pagination.totalPages
        }));
      } else {
        setItems(response.data);
      }
    } catch (error) {
      console.error("Failed to fetch incoming correspondence", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchMetadata = async () => {
    try {
      const [deptsRes, usersRes] = await Promise.all([
        api.get('/org-entities'),
        api.get('/users')
      ]);
      setDepartments(deptsRes.data);
      setUsers(usersRes.data);
    } catch (error) {
      console.error("Failed to fetch metadata", error);
    }
  };

  const handleExport = () => {
    const headers = [
      t('correspondence.seqNumber'),
      t('correspondence.letterNo'),
      t('correspondence.sender'),
      t('correspondence.subject'),
      t('correspondence.date'),
      t('correspondence.status'),
      t('correspondence.priority')
    ];

    const csvData = items.map(item => [
      item.sequence_number,
      item.letter_number || '',
      item.sender_entity,
      item.subject,
      item.letter_date,
      item.status,
      item.priority
    ]);

    const csvContent = [
      headers.join(','),
      ...csvData.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `incoming_correspondence_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Received': return 'bg-[var(--color-primary)]/10 text-[var(--color-primary)]';
      case 'Registered': return 'bg-[var(--color-secondary)]/10 text-[var(--color-secondary)]';
      case 'Under Review': return 'bg-[var(--color-warning)]/10 text-[var(--color-warning)]';
      case 'Referred': return 'bg-purple-500/10 text-purple-500';
      case 'Action Taken': return 'bg-teal-500/10 text-teal-500';
      case 'Closed': return 'bg-[var(--color-success)]/10 text-[var(--color-success)]';
      case 'Archived': return 'bg-[var(--color-text-muted)]/10 text-[var(--color-text-muted)]';
      case 'Cancelled': return 'bg-[var(--color-error)]/10 text-[var(--color-error)]';
      default: return 'bg-[var(--color-text-muted)]/10 text-[var(--color-text-muted)]';
    }
  };

  const getStatusLabel = (status: string) => {
    return t(`correspondence.${status.toLowerCase().replace(/\s+/g, '_')}`);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Normal': return 'text-[var(--color-text-muted)]';
      case 'Urgent': return 'text-[var(--color-warning)] font-semibold';
      case 'Very Urgent': return 'text-[var(--color-error)] font-bold';
      case 'Confidential': return 'text-purple-500 font-semibold';
      case 'Restricted': return 'text-[var(--color-primary)] font-semibold';
      default: return 'text-[var(--color-text-muted)]';
    }
  };

  const getPriorityLabel = (priority: string) => {
    return t(`correspondence.${priority.toLowerCase().replace(/\s+/g, '_')}`);
  };

  return (
    <div className="space-y-4">
      {/* Filters Bar */}
      <div className="glass-card p-4 flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute start-4 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)]" size={18} />
          <input 
            type="text"
            placeholder={t('correspondence.searchIncomingPlaceholder')}
            className="input-field !ps-12"
            value={filters.search}
            onChange={(e) => setFilters({...filters, search: e.target.value})}
          />
        </div>
        
        <select 
          className="input-field w-auto"
          value={filters.status}
          onChange={(e) => setFilters({...filters, status: e.target.value})}
        >
          <option value="">{t('correspondence.allStatuses')}</option>
          <option value="Received">{t('correspondence.received')}</option>
          <option value="Registered">{t('correspondence.registered')}</option>
          <option value="Under Review">{t('correspondence.under_review')}</option>
          <option value="Referred">{t('correspondence.referred')}</option>
          <option value="Action Taken">{t('correspondence.action_taken')}</option>
          <option value="Closed">{t('correspondence.closed')}</option>
        </select>

        <select 
          className="input-field w-auto"
          value={filters.priority}
          onChange={(e) => setFilters({...filters, priority: e.target.value})}
        >
          <option value="">{t('correspondence.allPriorities')}</option>
          <option value="Normal">{t('correspondence.normal')}</option>
          <option value="Urgent">{t('correspondence.urgent')}</option>
          <option value="Very Urgent">{t('correspondence.very_urgent')}</option>
          <option value="Confidential">{t('correspondence.confidential')}</option>
          <option value="Restricted">{t('correspondence.restricted')}</option>
        </select>

        <button 
          onClick={handleExport}
          className="btn-secondary"
          title={t('correspondence.exportToCSV')}
        >
          <Download size={18} />
          {t('correspondence.export')}
        </button>

        <button 
          onClick={() => setShowAddModal(true)}
          className="btn-primary"
        >
          <Plus size={18} />
          {t('correspondence.addNew')}
        </button>
      </div>

      {/* Table */}
      <div className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-start">
            <thead className="bg-slate-50 dark:bg-slate-900/50 text-[var(--color-text-muted)] font-bold border-b border-[var(--color-border-soft)]">
              <tr>
                <th className="px-6 py-4 text-start bg-[var(--color-primary)]/5 border-s-4 border-[var(--color-primary)] text-[var(--color-primary)] uppercase tracking-wider text-xs">
                  {t('correspondence.seqNumber')}
                </th>
                <th className="px-6 py-4 text-start">{t('correspondence.letterNo')}</th>
                <th className="px-6 py-4">{t('correspondence.sender')}</th>
                <th className="px-6 py-4">{t('correspondence.subject')}</th>
                <th className="px-6 py-4">{t('correspondence.date')}</th>
                <th className="px-6 py-4">{t('correspondence.status')}</th>
                <th className="px-6 py-4">{t('correspondence.priority')}</th>
                <th className="px-6 py-4">{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--color-border-soft)]">
              {loading ? (
                <tr>
                  <td colSpan={8} className="px-6 py-10 text-center text-[var(--color-text-muted)] italic">
                    {t('common.loading')}
                  </td>
                </tr>
              ) : items.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-6 py-10 text-center text-[var(--color-text-muted)] italic">
                    {t('correspondence.noMatchingResults')}
                  </td>
                </tr>
              ) : (Array.isArray(items) ? items : []).map((item) => (
                <tr key={item.id} className="hover:bg-[var(--color-bg-main)] transition-colors">
                  <td className="px-6 py-4 font-mono font-medium text-[var(--color-primary)]">{formatNumber(item.sequence_number)}</td>
                  <td className="px-6 py-4 text-[var(--color-text-main)]">{formatNumber(item.letter_number) || '-'}</td>
                  <td className="px-6 py-4 text-[var(--color-text-main)]">
                    <div className="flex items-center gap-2">
                      <Building size={14} className="text-[var(--color-text-muted)]" />
                      {item.sender_entity}
                    </div>
                  </td>
                  <td className="px-6 py-4 font-medium max-w-xs truncate text-[var(--color-text-main)]">{item.subject}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-[var(--color-text-main)]">
                    <div className="flex flex-col">
                      <span>{formatDate(item.letter_date)}</span>
                      <span className="text-xs text-[var(--color-text-muted)]">{t('correspondence.recPrefix')}{formatDate(item.receipt_date)}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(item.status)}`}>
                      {getStatusLabel(item.status)}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`flex items-center gap-1 text-xs ${getPriorityColor(item.priority)}`}>
                      <Tag size={12} />
                      {getPriorityLabel(item.priority)}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => onViewDetails(item.id)}
                        className="p-2 text-[var(--color-text-muted)] hover:text-[var(--color-primary)] hover:bg-[var(--color-primary)]/10 rounded-lg transition-colors"
                        title={t('correspondence.viewDetails')}
                      >
                        <Eye size={18} />
                      </button>
                      <button 
                        className="p-2 text-[var(--color-text-muted)] hover:text-[var(--color-text-main)] hover:bg-[var(--color-bg-main)] rounded-lg transition-colors"
                      >
                        <MoreVertical size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Pagination 
        currentPage={pagination.page}
        totalPages={pagination.totalPages}
        onPageChange={(page) => setPagination(prev => ({ ...prev, page }))}
        pageSize={pagination.pageSize}
        onPageSizeChange={(pageSize) => setPagination(prev => ({ ...prev, pageSize, page: 1 }))}
        totalItems={pagination.total}
      />

      {/* Add Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-card w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col"
            >
              <div className="p-6 border-b border-[var(--color-border-soft)] flex items-center justify-between bg-[var(--color-bg-main)]">
                <h2 className="text-xl font-bold text-[var(--color-text-main)] flex items-center gap-2">
                  <Mail className="text-[var(--color-primary)]" />
                  {t('correspondence.registerIncomingTitle')}
                </h2>
                <button 
                  onClick={() => setShowAddModal(false)}
                  className="p-2 text-[var(--color-text-muted)] hover:text-[var(--color-text-main)] rounded-full hover:bg-[var(--color-border-soft)] transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
              
              <div className="p-6 overflow-y-auto flex-1">
                <IncomingForm 
                  language={language} 
                  departments={departments}
                  users={users}
                  onSuccess={() => {
                    setShowAddModal(false);
                    fetchData();
                  }}
                  onCancel={() => setShowAddModal(false)}
                />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default IncomingRegister;
