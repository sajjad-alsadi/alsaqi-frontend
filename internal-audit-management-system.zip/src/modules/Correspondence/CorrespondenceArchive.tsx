import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Archive, 
  Eye, 
  Download, 
  Mail, 
  Send,
  Calendar,
  Building,
  Filter
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import api from '../../services/api';
import Pagination from '../../components/Pagination';
import { useFormat } from '../../services/formatService';
import { useDebounce } from '../../hooks/useDebounce';

interface CorrespondenceArchiveProps {
  language: 'ar' | 'en';
  onViewDetails: (type: 'Incoming' | 'Outgoing', id: number) => void;
}

const CorrespondenceArchive: React.FC<CorrespondenceArchiveProps> = ({ language, onViewDetails }) => {
  const { t } = useTranslation();
  const { formatNumber, formatDate } = useFormat();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 500);
  const [typeFilter, setTypeFilter] = useState<'All' | 'Incoming' | 'Outgoing'>('All');
  const [pagination, setPagination] = useState({ page: 1, pageSize: 15, total: 0, totalPages: 0 });

  useEffect(() => {
    fetchArchived();
  }, [debouncedSearch, typeFilter, pagination.page, pagination.pageSize]);

  const fetchArchived = async () => {
    try {
      setLoading(true);
      const response = await api.get('/correspondence/archive', {
        params: {
          page: pagination.page,
          pageSize: pagination.pageSize,
          type: typeFilter !== 'All' ? typeFilter : undefined,
          search: debouncedSearch || undefined
        }
      });
      
      if (response.data.data) {
        setItems(response.data.data);
        setPagination(prev => ({
          ...prev,
          total: response.data.pagination.total,
          totalPages: response.data.pagination.totalPages
        }));
      }
    } catch (error) {
      console.error("Failed to fetch archived correspondence", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="glass-card p-4 flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[250px]">
          <Search className="absolute start-4 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)]" size={18} />
          <input 
            type="text"
            placeholder={t('correspondence.searchArchivePlaceholder')}
            className="input-field !ps-12"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPagination(prev => ({ ...prev, page: 1 }));
            }}
          />
        </div>
        
        <div className="flex bg-[var(--color-bg-main)] p-1 rounded-xl border border-[var(--color-border-soft)]">
          <button 
            onClick={() => {
              setTypeFilter('All');
              setPagination(prev => ({ ...prev, page: 1 }));
            }}
            className={`px-4 py-2 rounded-lg text-sm font-bold transition-colors ${typeFilter === 'All' ? 'bg-white text-[var(--color-primary)] shadow-sm' : 'text-[var(--color-text-muted)] hover:text-[var(--color-text-main)]'}`}
          >
            {t('correspondence.all')}
          </button>
          <button 
            onClick={() => {
              setTypeFilter('Incoming');
              setPagination(prev => ({ ...prev, page: 1 }));
            }}
            className={`px-4 py-2 rounded-lg text-sm font-bold transition-colors ${typeFilter === 'Incoming' ? 'bg-white text-[var(--color-primary)] shadow-sm' : 'text-[var(--color-text-muted)] hover:text-[var(--color-text-main)]'}`}
          >
            {t('correspondence.incoming')}
          </button>
          <button 
            onClick={() => {
              setTypeFilter('Outgoing');
              setPagination(prev => ({ ...prev, page: 1 }));
            }}
            className={`px-4 py-2 rounded-lg text-sm font-bold transition-colors ${typeFilter === 'Outgoing' ? 'bg-white text-[var(--color-primary)] shadow-sm' : 'text-[var(--color-text-muted)] hover:text-[var(--color-text-main)]'}`}
          >
            {t('correspondence.outgoing')}
          </button>
        </div>
      </div>

      <div className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-start">
            <thead className="bg-[var(--color-bg-main)] text-[var(--color-text-muted)] font-medium border-b border-[var(--color-border-soft)]">
              <tr>
                <th className="px-6 py-4">{t('correspondence.type')}</th>
                <th className="px-6 py-4">{t('correspondence.seqNumber')}</th>
                <th className="px-6 py-4">{t('correspondence.subject')}</th>
                <th className="px-6 py-4">{t('correspondence.entity')}</th>
                <th className="px-6 py-4">{t('correspondence.archiveDate')}</th>
                <th className="px-6 py-4">{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--color-border-soft)]">
              {loading ? (
                <tr>
                  <td colSpan={6} className="px-6 py-10 text-center text-[var(--color-text-muted)] italic">
                    {t('common.loading')}
                  </td>
                </tr>
              ) : items.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-10 text-center text-[var(--color-text-muted)] italic">
                    {t('correspondence.archiveIsEmpty')}
                  </td>
                </tr>
              ) : (Array.isArray(items) ? items : []).map((item, idx) => (
                <tr key={idx} className="hover:bg-[var(--color-bg-main)] transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {item.type === 'Incoming' ? (
                        <Mail size={16} className="text-[var(--color-primary)]" />
                      ) : (
                        <Send size={16} className="text-[var(--color-success)]" />
                      )}
                      <span className="text-xs font-bold uppercase text-[var(--color-text-main)]">{t(`correspondence.${item.type.toLowerCase()}`)}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 font-mono font-medium text-[var(--color-primary)]">{formatNumber(item.sequence_number)}</td>
                  <td className="px-6 py-4 font-medium max-w-xs truncate text-[var(--color-text-main)]">{item.subject}</td>
                  <td className="px-6 py-4 text-[var(--color-text-main)]">{item.entity}</td>
                  <td className="px-6 py-4 text-[var(--color-text-muted)]">
                    <div className="flex items-center gap-2">
                      <Calendar size={14} />
                      {formatDate(item.updated_at) || '-'}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <button 
                      onClick={() => onViewDetails(item.type, item.id)}
                      className="p-2 text-[var(--color-text-muted)] hover:text-[var(--color-primary)] hover:bg-[var(--color-primary)]/10 rounded-lg transition-colors"
                      title={t('correspondence.viewDetails')}
                    >
                      <Eye size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Pagination 
        currentPage={pagination.page}
        totalPages={pagination.totalPages}
        onPageChange={(page) => setPagination(prev => ({ ...prev, page }))}
        pageSize={pagination.pageSize}
        onPageSizeChange={(pageSize) => setPagination(prev => ({ ...prev, pageSize, page: 1 }))}
        totalItems={pagination.total}
      />
    </div>
  );
};

export default CorrespondenceArchive;
