import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import Modal from '../../../components/Modal';
import { FraudCase } from '../types';

interface AddCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (newCase: Partial<FraudCase>) => Promise<boolean>;
}

export const AddCaseModal: React.FC<AddCaseModalProps> = ({ isOpen, onClose, onAdd }) => {
  const { t } = useTranslation();
  const [newCase, setNewCase] = useState<Partial<FraudCase>>({
    riskCategory: 'Financial',
    status: 'Open'
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await onAdd(newCase);
    if (success) {
      onClose();
      setNewCase({ riskCategory: 'Financial', status: 'Open' });
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={t('reportNewCase')}
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t('detectionDate')}</label>
            <input 
              type="date" 
              required
              className="input-field"
              value={newCase.detectionDate || ''}
              onChange={e => setNewCase({...newCase, detectionDate: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t('detectionSource')}</label>
            <input 
              type="text" 
              required
              placeholder={t('detectionSource')}
              className="input-field"
              value={newCase.source || ''}
              onChange={e => setNewCase({...newCase, source: e.target.value})}
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t('riskCategory')}</label>
            <select 
              className="input-field"
              value={newCase.riskCategory}
              onChange={e => setNewCase({...newCase, riskCategory: e.target.value as any})}
            >
              <option value="Financial">{t('financial')}</option>
              <option value="Operational">{t('operational')}</option>
              <option value="Compliance">{t('compliance')}</option>
              <option value="Reputational">{t('reputational')}</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t('financialImpact')}</label>
            <input 
              type="text" 
              placeholder={t('financialImpact')}
              className="input-field"
              value={newCase.financialImpact || ''}
              onChange={e => setNewCase({...newCase, financialImpact: e.target.value})}
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t('condition')} / {t('description')}</label>
          <textarea 
            required
            rows={3}
            className="input-field"
            value={newCase.condition || ''}
            onChange={e => setNewCase({...newCase, condition: e.target.value})}
          />
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t('suspects')} ({t('fraud')})</label>
          <input 
            type="text" 
            className="input-field border-rose-200 focus:border-rose-500 focus:ring-rose-200"
            placeholder={t('suspects')}
            value={newCase.suspects || ''}
            onChange={e => setNewCase({...newCase, suspects: e.target.value})}
          />
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t('correctiveActions')}</label>
          <textarea 
            rows={3}
            className="input-field"
            value={newCase.correctiveActions || ''}
            onChange={e => setNewCase({...newCase, correctiveActions: e.target.value})}
          />
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">{t('status')}</label>
          <select 
            className="input-field"
            value={newCase.status}
            onChange={e => setNewCase({...newCase, status: e.target.value as any})}
          >
            <option value="Open">{t('open')}</option>
            <option value="Under Investigation">{t('underInvestigation')}</option>
            <option value="Closed - Convicted">{t('closedConvicted')}</option>
            <option value="Closed - Insufficient Evidence">{t('closedInsufficientEvidence')}</option>
          </select>
        </div>

        <div className="flex justify-end gap-4 pt-4 border-t border-slate-100">
          <button 
            type="button"
            onClick={onClose}
            className="btn-secondary"
          >
            {t('common.cancel')}
          </button>
          <button 
            type="submit"
            className="btn-primary bg-rose-600 hover:bg-rose-700"
          >
            {t('saveCase')}
          </button>
        </div>
      </form>
    </Modal>
  );
};
