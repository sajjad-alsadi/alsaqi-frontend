import React, { useState } from 'react';
import { ShieldAlert, Lock, Plus, FileText } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useAppContext } from '../../context/AppContext';

// Refactored Assets
import { useFraudLog } from './hooks/useFraudLog';
import { AccessGate } from './components/AccessGate';
import { FraudTable } from './components/FraudTable';
import { AddCaseModal } from './components/AddCaseModal';

const FraudLog: React.FC = () => {
  const { user } = useAppContext();
  const { t } = useTranslation();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isPolicyOpen, setIsPolicyOpen] = useState(false);
  const [policyContent, setPolicyContent] = useState('');

  const isManager = user?.role === 'Admin' || user?.role === 'Administrator' || user?.role === 'Manager';
  
  const {
    cases,
    policyContent: currentPolicy,
    requests,
    accessStatus,
    myRequest,
    hasAccess,
    isRequestModalOpen,
    setIsRequestModalOpen,
    requestReason,
    setRequestReason,
    requestError,
    submitAccessRequest,
    approveRequest,
    rejectRequest,
    addCase,
    savePolicy
  } = useFraudLog(isManager);

  // Sync internal state for editing if needed
  const [editingPolicy, setEditingPolicy] = useState(currentPolicy);

  if (!hasAccess) {
    return (
      <AccessGate 
        isManager={isManager}
        accessStatus={accessStatus}
        myRequest={myRequest}
        requests={requests}
        isRequestModalOpen={isRequestModalOpen}
        setIsRequestModalOpen={setIsRequestModalOpen}
        requestReason={requestReason}
        setRequestReason={setRequestReason}
        requestError={requestError}
        submitAccessRequest={submitAccessRequest}
        approveRequest={approveRequest}
        rejectRequest={rejectRequest}
        policyContent={editingPolicy || currentPolicy}
        setPolicyContent={setEditingPolicy}
        savePolicy={savePolicy}
        fetchPolicy={async () => {}} // Hook handles re-fetch on success inside savePolicy mostly or via effects
      />
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 bg-rose-500 rounded-[1.5rem] flex items-center justify-center text-white shadow-2xl shadow-rose-200">
            <ShieldAlert size={32} />
          </div>
          <div>
            <h2 className="text-4xl font-black text-slate-800 tracking-tight">{t('fraudLog')}</h2>
            <p className="text-sm text-rose-600 font-black uppercase tracking-[0.2em] mt-2 flex items-center gap-2">
              <Lock size={14} />
              {t('confidentialAccess')}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsPolicyOpen(true)}
            className="btn-secondary flex items-center gap-2"
          >
            <FileText size={18} />
            {t('viewPolicy')}
          </button>
          {isManager && (
            <button 
              onClick={() => setIsAddModalOpen(true)}
              className="btn-primary bg-rose-600 hover:bg-rose-700 flex items-center gap-2"
            >
              <Plus size={20} />
              {t('reportCase')}
            </button>
          )}
        </div>
      </div>

      <AccessGate 
        isManager={isManager}
        accessStatus={accessStatus}
        myRequest={myRequest}
        requests={requests}
        isRequestModalOpen={isRequestModalOpen}
        setIsRequestModalOpen={setIsRequestModalOpen}
        requestReason={requestReason}
        setRequestReason={setRequestReason}
        requestError={requestError}
        submitAccessRequest={submitAccessRequest}
        approveRequest={approveRequest}
        rejectRequest={rejectRequest}
        policyContent={editingPolicy || currentPolicy}
        setPolicyContent={setEditingPolicy}
        savePolicy={savePolicy}
        fetchPolicy={async () => {}}
      />

      <FraudTable cases={cases} />

      <AddCaseModal 
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAdd={addCase}
      />
    </div>
  );
};

export default FraudLog;
