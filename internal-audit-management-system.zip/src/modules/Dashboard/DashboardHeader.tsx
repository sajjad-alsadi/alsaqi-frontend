import React from 'react';
import { LayoutDashboard, ShieldCheck, Download } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Language } from '../../constants';
import { useFormat } from '../../services/formatService';

import { generateAuditReport } from '../../services/pdfService';

interface DashboardHeaderProps {
  language: string;
  activeFilter: string;
  setActiveFilter: (filter: string) => void;
}

const DashboardHeader: React.FC<DashboardHeaderProps> = React.memo(({ language, activeFilter, setActiveFilter }) => {
  const { t } = useTranslation();
  const { formatDate } = useFormat();

  const handleExportPdf = async () => {
    try {
      await generateAuditReport({}, { language: language as 'ar' | 'en' });
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert(t('common.error'));
    }
  };

  return (
    <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
      <div>
        <h1 className="text-3xl font-black text-[var(--color-text-main)] tracking-tight mb-2 flex items-center gap-3">
          <LayoutDashboard className="text-[var(--color-primary)]" size={32} />
          {t('dashboard.executiveDashboard')}
        </h1>
        <p className="text-[var(--color-text-muted)] font-bold flex items-center gap-2 text-sm">
          <ShieldCheck size={18} className="text-[var(--color-success)]" />
          {t('dashboard.controlCenter')} • {formatDate(new Date())}
        </p>
      </div>
      
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1 bg-[var(--color-card)] p-1.5 rounded-[1.5rem] shadow-sm border border-[var(--color-border-soft)]">
          {['all', 'operational', 'financial', 'it'].map(filter => (
            <button 
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${activeFilter === filter ? 'bg-[var(--color-primary)] text-white shadow-md' : 'text-[var(--color-text-muted)] hover:text-[var(--color-text-main)]'}`}
            >
              {t(`dashboard.${filter}`)}
            </button>
          ))}
        </div>
        <button 
          onClick={handleExportPdf}
          className="p-3 bg-[var(--color-card)] rounded-[1.5rem] shadow-sm border border-[var(--color-border-soft)] text-[var(--color-text-muted)] hover:text-[var(--color-primary)] transition-all"
          title={t('common.exportPdf')}
        >
          <Download size={20} />
        </button>
      </div>
    </div>
  );
});

export default DashboardHeader;
