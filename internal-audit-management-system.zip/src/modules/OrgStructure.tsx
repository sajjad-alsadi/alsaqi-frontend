import React from 'react';
import { motion } from 'motion/react';
import { Users } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const OrgStructure: React.FC = () => {
  const { t } = useTranslation();
  return (
    <div className="p-8">
      <div className="glass-card p-20 text-center">
        <div className="w-24 h-24 bg-slate-50 rounded-[2rem] flex items-center justify-center mx-auto mb-8 text-slate-300 shadow-inner">
          <Users size={48} />
        </div>
        <h3 className="text-2xl font-black text-slate-800 mb-3 tracking-tight">{t('organizationalStructure')}</h3>
        <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">{t('underDevelopment')}</p>
      </div>
    </div>
  );
};

export default OrgStructure;
