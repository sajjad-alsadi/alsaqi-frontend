import React from 'react';
import { motion } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { AccessScope } from '../../constants';
import { ROLES } from '../../permissions';

import { useFormat } from '../../services/formatService';
import { useDepartments } from '../../hooks/useDepartments';

interface UserFormProps {
  editingUser: any;
  newUser: any;
  userError: string;
  jobTitles: any[];
  users: any[];
  allRoles: any[];
  getRoleLabel: (role: string) => string;
  onCancel: () => void;
  onSave: () => void;
  onUpdateNewUser: (data: any) => void;
}

const UserForm: React.FC<UserFormProps> = ({
  editingUser,
  newUser,
  userError,
  jobTitles,
  users,
  allRoles,
  getRoleLabel,
  onCancel,
  onSave,
  onUpdateNewUser
}) => {
  const { t } = useTranslation();
  const { translateName } = useFormat();
  const { departments } = useDepartments();

  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-card p-10 border-[var(--color-primary)]/20"
    >
      <h3 className="text-xl font-black text-[var(--color-text-main)] mb-8">{editingUser ? t('userManagement.editUser') : t('userManagement.addUser')}</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-2">
          <label className="text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest">{t('userManagement.form.username')}</label>
          <input className="input-field" placeholder={t('userManagement.form.username')} value={newUser.username || ''} onChange={e => onUpdateNewUser({ username: e.target.value })} disabled={!!editingUser} />
        </div>
        {!editingUser && (
          <div className="space-y-2">
            <label className="text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest">{t('userManagement.form.password')}</label>
            <input className="input-field" type="password" placeholder={t('userManagement.form.password')} value={newUser.password || ''} onChange={e => onUpdateNewUser({ password: e.target.value })} />
          </div>
        )}
        <div className="space-y-2">
          <label className="text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest">{t('userManagement.form.fullName')}</label>
          <input className="input-field" placeholder={t('userManagement.form.fullName')} value={newUser.name || ''} onChange={e => onUpdateNewUser({ name: e.target.value })} />
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest">{t('userManagement.form.email')}</label>
          <input className="input-field" placeholder={t('userManagement.form.email')} value={newUser.email || ''} onChange={e => onUpdateNewUser({ email: e.target.value })} />
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest">{t('userManagement.form.phoneNumber')}</label>
          <input className="input-field" placeholder={t('userManagement.form.phoneNumber')} value={newUser.phone_number || ''} onChange={e => onUpdateNewUser({ phone_number: e.target.value })} />
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest">{t('userManagement.form.jobTitle')}</label>
          <select className="input-field" value={newUser.job_title_id || ''} onChange={e => onUpdateNewUser({ job_title_id: e.target.value })}>
            <option value="">{t('userManagement.form.selectJobTitle')}</option>
            {jobTitles.map(title => (
              <option key={title.id} value={title.id}>{title.name}</option>
            ))}
          </select>
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest">{t('userManagement.form.department')}</label>
          <select className="input-field" value={newUser.department || ''} onChange={e => onUpdateNewUser({ department: e.target.value })}>
            <option value="">{t('userManagement.form.selectDepartment')}</option>
            {departments.map(dept => (
              <option key={dept.id} value={dept.name}>{dept.name}</option>
            ))}
          </select>
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest">{t('userManagement.form.unit')}</label>
          <input className="input-field" placeholder={t('userManagement.form.unit')} value={newUser.unit || ''} onChange={e => onUpdateNewUser({ unit: e.target.value })} />
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest">{t('userManagement.form.reportingManager')}</label>
          <select className="input-field" value={newUser.reporting_manager_id || ''} onChange={e => onUpdateNewUser({ reporting_manager_id: e.target.value })}>
            <option value="">{t('userManagement.form.selectManager')}</option>
            {users.filter(u => u.id !== editingUser?.id).map(u => (
              <option key={u.id} value={u.id}>{translateName(u.name)}</option>
            ))}
          </select>
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest">{t('userManagement.form.accessScope')}</label>
          <select className="input-field" value={newUser.access_scope || AccessScope.GLOBAL} onChange={e => onUpdateNewUser({ access_scope: e.target.value })}>
            <option value={AccessScope.GLOBAL}>{t('userManagement.form.global')}</option>
            <option value={AccessScope.DEPARTMENT}>{t('userManagement.form.department')}</option>
            <option value={AccessScope.UNIT}>{t('userManagement.form.unit')}</option>
          </select>
        </div>
        <div className="space-y-2">
          <label className="text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest">{t('common.role')}</label>
          <select className="input-field" value={newUser.role || ROLES.VIEWER} onChange={e => onUpdateNewUser({ role: e.target.value })}>
            {allRoles.map(role => (
              <option key={role.id} value={role.name}>{getRoleLabel(role.name)}</option>
            ))}
          </select>
        </div>
        <div className="md:col-span-2 space-y-2">
          <label className="text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest">{t('userManagement.form.notes')}</label>
          <textarea 
            className="input-field min-h-[100px]" 
            placeholder={t('userManagement.form.additionalNotes')} 
            value={newUser.notes || ''} 
            onChange={e => onUpdateNewUser({ notes: e.target.value })}
          />
        </div>
      </div>
      {userError && (
        <div className="mt-4 p-3 bg-[var(--color-danger)]/10 text-[var(--color-danger)] rounded-lg text-sm">
          {userError}
        </div>
      )}
      <div className="flex justify-end gap-4 mt-8">
        <button onClick={onCancel} className="btn-secondary">{t('common.cancel')}</button>
        <button onClick={onSave} className="btn-primary">{editingUser ? t('common.save') : t('userManagement.addUser')}</button>
      </div>
    </motion.div>
  );
};

export default UserForm;
