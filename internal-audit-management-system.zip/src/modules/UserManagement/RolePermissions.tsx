import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Shield, Save, CheckCircle, ChevronRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { PERMISSIONS } from '../../permissions';
import { useFormat } from '../../services/formatService';

interface RolePermissionsProps {
  allRoles: any[];
  allPermissions: any[];
  showSaveSuccess: boolean;
  getRoleLabel: (role: string) => string;
  onSave: (modifiedRoles: any[]) => void;
}

const RolePermissions: React.FC<RolePermissionsProps> = ({
  allRoles,
  allPermissions,
  showSaveSuccess,
  getRoleLabel,
  onSave
}) => {
  const { t } = useTranslation();
  const { formatNumber } = useFormat();
  const [selectedRoleId, setSelectedRoleId] = useState<number | null>(null);
  const [localRoles, setLocalRoles] = useState<any[]>([]);
  const [isDirty, setIsDirty] = useState(false);
  const [modifiedRoleIds, setModifiedRoleIds] = useState<Set<number>>(new Set());

  // Initialize selected role and local state when roles are loaded
  useEffect(() => {
    if (allRoles.length > 0 && selectedRoleId === null) {
      setSelectedRoleId(allRoles[0].id);
    }
    if (!isDirty && allRoles.length > 0) {
      setLocalRoles(JSON.parse(JSON.stringify(allRoles)));
      setModifiedRoleIds(new Set());
    }
  }, [allRoles, selectedRoleId, isDirty]);

  const handleToggle = (roleId: number, permId: number, checked: boolean) => {
    setLocalRoles(prev => prev.map(role => {
      if (role.id === roleId) {
        const perms = role.permissions || [];
        if (checked) {
          const permObj = allPermissions.find(p => p.id === permId);
          return { ...role, permissions: [...perms, permObj] };
        } else {
          return { ...role, permissions: perms.filter((p: any) => p.id !== permId) };
        }
      }
      return role;
    }));
    setModifiedRoleIds(prev => new Set(prev).add(roleId));
    setIsDirty(true);
  };

  const handleSave = () => {
    const rolesToSave = localRoles.filter(r => modifiedRoleIds.has(r.id));
    onSave(rolesToSave);
    setIsDirty(false);
    setModifiedRoleIds(new Set());
  };

  // Group permissions by module
  const modules = Array.from(new Set(allPermissions.map(p => p.module)));
  const actions = Object.values(PERMISSIONS);

  const selectedRole = localRoles.find(r => r.id === selectedRoleId);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-[var(--color-primary)]/10 rounded-2xl flex items-center justify-center text-[var(--color-primary)]">
            <Shield size={24} />
          </div>
          <div>
            <h3 className="text-2xl font-black text-[var(--color-text-main)]">{t('userManagement.roles.title')}</h3>
            <p className="text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-widest">{t('userManagement.roles.subtitle')}</p>
          </div>
        </div>
        <button 
          onClick={handleSave} 
          disabled={!isDirty}
          className={`btn-primary flex items-center gap-2 ${!isDirty ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <Save size={18} />
          {t('common.save')}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Roles Sidebar */}
        <div className="lg:col-span-1 space-y-2">
          <p className="text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest px-4 mb-4">{t('userManagement.roles.rolesLabel')}</p>
          {localRoles.map(role => (
            <button
              key={role.id}
              onClick={() => setSelectedRoleId(role.id)}
              className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all duration-300 ${
                selectedRoleId === role.id 
                  ? 'bg-[var(--color-primary)] text-white shadow-xl shadow-[var(--color-primary)]/20 translate-x-2' 
                  : 'bg-[var(--color-card)] text-[var(--color-text-main)] hover:bg-[var(--color-bg-soft)] border border-[var(--color-border-soft)]'
              }`}
            >
              <div className="text-start">
                <p className="text-sm font-black">{getRoleLabel(role.name)}</p>
                <p className={`text-[10px] ${selectedRoleId === role.id ? 'text-white/70' : 'text-[var(--color-text-muted)]'}`}>
                  {formatNumber((role.permissions || []).length)} {t('userManagement.roles.permissionsLabel')}
                </p>
              </div>
              <ChevronRight size={16} className={selectedRoleId === role.id ? 'opacity-100' : 'opacity-0'} />
            </button>
          ))}
        </div>

        {/* Permissions Matrix */}
        <div className="lg:col-span-3">
          <div className="glass-card overflow-hidden border-[var(--color-border-soft)]">
            <div className="overflow-x-auto">
              <table className="w-full text-start border-collapse">
                <thead>
                  <tr className="bg-[var(--color-bg-soft)] border-b border-[var(--color-border-soft)]">
                    <th className="px-8 py-6 text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest text-start min-w-[200px]">{t('userManagement.roles.module')}</th>
                    {actions.map(action => (
                      <th key={action} className="px-6 py-6 text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest text-center">
                        {t(`permissions.${action}`)}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--color-border-soft)]">
                  <AnimatePresence>
                    {modules.map((module, idx) => (
                      <motion.tr 
                        key={`${selectedRoleId}-${module}`}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.02 }}
                        className="hover:bg-[var(--color-bg-soft)]/50 transition-colors"
                      >
                        <td className="px-8 py-6">
                          <span className="text-sm font-black text-[var(--color-text-main)]">{t(`modules.${module}`)}</span>
                        </td>
                        {actions.map(action => {
                          const perm = allPermissions.find(p => p.module === module && p.action === action);
                          if (!perm) return <td key={action} className="px-6 py-6 text-center">-</td>;
                          
                          const hasPermission = (selectedRole?.permissions || []).some((p: any) => p.id === perm.id);
                          
                          return (
                            <td key={action} className="px-6 py-6 text-center">
                              <label className="relative inline-flex items-center cursor-pointer group">
                                <input 
                                  type="checkbox" 
                                  className="sr-only peer"
                                  checked={hasPermission}
                                  onChange={(e) => handleToggle(selectedRoleId!, perm.id, e.target.checked)}
                                />
                                <div className="w-11 h-6 bg-[var(--color-border-soft)] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-primary)] group-hover:shadow-md transition-all"></div>
                              </label>
                            </td>
                          );
                        })}
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {showSaveSuccess && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          className="fixed bottom-10 right-10 bg-[var(--color-success)] text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 z-50"
        >
          <CheckCircle size={24} />
          <span className="font-black uppercase tracking-widest text-xs">{t('settingsSavedSuccessfully')}</span>
        </motion.div>
      )}
    </div>
  );
};

export default RolePermissions;
