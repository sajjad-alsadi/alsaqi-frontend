import React from 'react';
import { motion } from 'motion/react';
import { Mail, Shield, Building, Edit, Trash2, Unlock } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useFormat } from '../../services/formatService';

interface UserListProps {
  users: any[];
  getRoleLabel: (role: string) => string;
  onEdit: (user: any) => void;
  onSuspend: (id: string) => void;
  onDelete: (id: string) => void;
  onResetPassword: (id: string) => void;
  onUnlock: (id: string) => void;
}

const UserList: React.FC<UserListProps> = ({
  users,
  getRoleLabel,
  onEdit,
  onSuspend,
  onDelete,
  onResetPassword,
  onUnlock
}) => {
  const { t, i18n } = useTranslation();
  const { translateStatus, formatDateTime, formatNumber, translateName } = useFormat();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {users.map((user, idx) => (
        <motion.div 
          key={user.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: idx * 0.05 }}
          className="glass-card group hover:shadow-2xl hover:shadow-[var(--color-primary)]/10 transition-all duration-500 overflow-hidden flex flex-col"
        >
          <div className="p-8 space-y-6 flex-1">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-[var(--color-bg-soft)] rounded-2xl flex items-center justify-center text-[var(--color-text-muted)] group-hover:bg-[var(--color-primary)]/10 group-hover:text-[var(--color-primary)] transition-colors duration-500">
                  <span className="text-xl font-black uppercase">{user.name?.charAt(0)}</span>
                </div>
                <div>
                  <h3 className="text-lg font-black text-[var(--color-text-main)] group-hover:text-[var(--color-primary)] transition-colors">{translateName(user.name)}</h3>
                  <p className="text-xs font-bold text-[var(--color-text-muted)]">@{user.username}</p>
                </div>
              </div>
              <div className="flex flex-col items-end gap-2">
                <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                  user.status === 'Active' ? 'bg-[var(--color-success)]/10 text-[var(--color-success)]' : 
                  user.status === 'Locked' ? 'bg-[var(--color-danger)]/10 text-[var(--color-danger)]' : 'bg-[var(--color-warning)]/10 text-[var(--color-warning)]'
                }`}>
                  {translateStatus(user.status)}
                </span>
                {user.status === 'Locked' && (
                  <div className="flex flex-col items-end gap-1">
                    <button 
                      onClick={() => onUnlock(user.id)}
                      className="flex items-center gap-1 text-[10px] font-black text-[var(--color-success)] hover:underline"
                    >
                      <Unlock size={12} />
                      {t('userManagement.userCard.unlock')}
                    </button>
                    <span className="text-[9px] font-bold text-[var(--color-danger)] uppercase tracking-tighter opacity-80">
                      {formatNumber(user.failed_attempts || 0)} {t('userManagement.userCard.failedAttempts')}
                    </span>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-3 text-[var(--color-text-muted)]">
                <Mail size={16} className="opacity-50" />
                <span className="text-xs font-bold truncate">{user.email}</span>
              </div>
              <div className="flex items-center gap-3 text-[var(--color-text-muted)]">
                <Shield size={16} className="opacity-50" />
                <span className="text-xs font-bold">{getRoleLabel(user.role)}</span>
              </div>
              <div className="flex items-center gap-3 text-[var(--color-text-muted)]">
                <Building size={16} className="opacity-50" />
                <span className="text-xs font-bold">{user.department}</span>
              </div>
            </div>

            <div className="pt-4 border-t border-[var(--color-border-soft)] flex items-center justify-between">
              <span className="text-[10px] font-black text-[var(--color-text-muted)] uppercase tracking-widest">{t('userManagement.userCard.lastLogin')}</span>
              <span className="text-[10px] font-bold text-[var(--color-text-main)] opacity-80">{user.last_login ? formatDateTime(user.last_login) : t('userManagement.userCard.never')}</span>
            </div>
          </div>

          <div className="p-6 bg-[var(--color-bg-soft)]/50 border-t border-[var(--color-border-soft)] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button 
                onClick={() => onEdit(user)}
                className="p-2 text-[var(--color-text-muted)] hover:text-[var(--color-primary)] hover:bg-[var(--color-card)] rounded-xl transition-all"
                title={t('common.edit')}
              >
                <Edit size={18} />
              </button>
              <button 
                onClick={() => onResetPassword(user.id)}
                className="p-2 text-[var(--color-text-muted)] hover:text-[var(--color-warning)] hover:bg-[var(--color-card)] rounded-xl transition-all"
                title={t('userManagement.resetPassword')}
              >
                <Shield size={18} />
              </button>
              <button 
                onClick={() => onDelete(user.id)}
                className="p-2 text-[var(--color-text-muted)] hover:text-[var(--color-danger)] hover:bg-[var(--color-card)] rounded-xl transition-all"
                title={t('common.delete')}
              >
                <Trash2 size={18} />
              </button>
            </div>
            <button 
              onClick={() => onSuspend(user.id)}
              className={`text-[10px] font-black uppercase tracking-widest px-4 py-2 rounded-xl transition-all ${
                user.status === 'Active' ? 'text-[var(--color-warning)] hover:bg-[var(--color-warning)]/10' : 'text-[var(--color-success)] hover:bg-[var(--color-success)]/10'
              }`}
            >
              {user.status === 'Active' ? t('userManagement.userCard.suspend') : t('userManagement.userCard.activate')}
            </button>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default UserList;
