import React from 'react';
import { User, Search, Save, UserPlus } from 'lucide-react';
import { motion } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { UserManagementTab } from '../../constants';
import { useFormat } from '../../services/formatService';

interface UserManagementHeaderProps {
  activeTab: UserManagementTab;
  searchTerm: string;
  resetRequestsCount: number;
  onTabChange: (tab: UserManagementTab) => void;
  onSearchChange: (term: string) => void;
  onExport: () => void;
  onAddUser: () => void;
}

const UserManagementHeader: React.FC<UserManagementHeaderProps> = ({
  activeTab,
  searchTerm,
  resetRequestsCount,
  onTabChange,
  onSearchChange,
  onExport,
  onAddUser
}) => {
  const { t } = useTranslation();
  const { formatNumber } = useFormat();

  return (
    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
      <div className="flex items-center gap-6">
        <div className="w-16 h-16 bg-primary/10 rounded-[1.5rem] flex items-center justify-center text-primary shadow-xl shadow-primary/5">
          <User size={32} />
        </div>
        <div>
          <h2 className="text-4xl font-black text-[var(--color-text-main)] tracking-tight">{t('userManagement.title')}</h2>
          <p className="text-sm text-[var(--color-text-muted)] font-bold mt-2 uppercase tracking-widest">{t('userManagement.subtitle')}</p>
        </div>
      </div>
      
      <div className="flex flex-col lg:flex-row lg:items-center gap-4">
        <div className="flex bg-[var(--color-bg-soft)] backdrop-blur-sm p-1.5 rounded-2xl border border-[var(--color-border-soft)] shadow-inner overflow-x-auto no-scrollbar">
          {Object.values(UserManagementTab).map((tab) => (
            <button 
              key={tab}
              onClick={() => onTabChange(tab)}
              className={`px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap flex items-center gap-2 ${
                activeTab === tab 
                  ? 'bg-[var(--color-card)] text-[var(--color-primary)] shadow-md ring-1 ring-[var(--color-border-soft)]' 
                  : 'text-[var(--color-text-muted)] hover:text-[var(--color-text-main)] hover:bg-[var(--color-card)]/50'
              }`}
            >
              {t(`userManagement.tabs.${tab}`)}
              {tab === UserManagementTab.RESETS && resetRequestsCount > 0 && (
                <span className="bg-[var(--color-danger)] text-white text-[10px] px-2 py-0.5 rounded-full shadow-sm animate-pulse">
                  {formatNumber(resetRequestsCount)}
                </span>
              )}
            </button>
          ))}
        </div>
        {activeTab === UserManagementTab.USERS && (
          <>
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute start-5 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)]" size={20} />
              <input 
                type="text"
                placeholder={t('userManagement.searchPlaceholder')}
                className="input-field !ps-14"
                value={searchTerm}
                onChange={(e) => onSearchChange(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onExport}
                className="btn-secondary flex items-center justify-center gap-3 whitespace-nowrap"
              >
                <Save size={20} />
                <span>{t('userManagement.export')}</span>
              </motion.button>
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onAddUser} 
                className="btn-primary flex items-center justify-center gap-3 whitespace-nowrap"
              >
                <UserPlus size={24} />
                <span>{t('userManagement.addUser')}</span>
              </motion.button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default UserManagementHeader;
