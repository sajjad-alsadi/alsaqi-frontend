import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { AlertCircle, RefreshCw, Trash2, Download, ChevronDown, ChevronUp } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useFormat } from '../../services/formatService';
import Pagination from '../../components/Pagination';
import SystemErrorAnalytics from './SystemErrorAnalytics';

interface SystemError {
  id: number;
  message: string;
  stack: string;
  module: string;
  timestamp: string;
  severity?: 'error' | 'warning' | 'info';
}

const SystemErrorLogs: React.FC = () => {
  const { t, i18n } = useTranslation();
  const { formatDate } = useFormat();
  const [logs, setLogs] = useState<SystemError[]>([]);
  const [analytics, setAnalytics] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [moduleFilter, setModuleFilter] = useState('');
  const [userIdFilter, setUserIdFilter] = useState('');
  const [severityFilter, setSeverityFilter] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [pagination, setPagination] = useState({ page: 1, pageSize: 20, total: 0, totalPages: 0 });
  const [expandedRows, setExpandedRows] = useState<number[]>([]);

  const toggleRow = (id: number) => {
    setExpandedRows(prev => prev.includes(id) ? prev.filter(rowId => rowId !== id) : [...prev, id]);
  };

  const fetchLogs = async () => {
    try {
      setLoading(true);
      const response = await api.get('/system-errors', {
        params: {
          page: pagination.page,
          pageSize: pagination.pageSize,
          module: moduleFilter || undefined,
          user_id: userIdFilter || undefined,
          severity: severityFilter || undefined,
          start_date: startDate || undefined,
          end_date: endDate || undefined
        }
      });
      if (response.data.data) {
        setLogs(response.data.data);
        setPagination(prev => ({
          ...prev,
          total: response.data.pagination.total,
          totalPages: response.data.pagination.totalPages
        }));
      } else {
        setLogs(response.data);
      }
    } catch (error) {
      console.error('Error fetching logs:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAnalytics = async () => {
    try {
      const response = await api.get('/system-errors/analytics');
      setAnalytics(response.data);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    }
  };

  const clearLogs = async () => {
    if (confirm(t('systemErrorLogs.confirmClearLogs'))) {
      try {
        await api.delete('/system-errors');
        fetchLogs();
      } catch (error) {
        console.error('Error clearing logs:', error);
      }
    }
  };

  const exportLogs = () => {
    window.location.href = '/api/system-errors/export';
  };

  const fetchLogsRef = React.useRef(fetchLogs);
  const fetchAnalyticsRef = React.useRef(fetchAnalytics);

  useEffect(() => {
    fetchLogsRef.current = fetchLogs;
    fetchAnalyticsRef.current = fetchAnalytics;
  });

  useEffect(() => {
    fetchLogs();
    fetchAnalytics();
  }, [pagination.page, pagination.pageSize, moduleFilter, userIdFilter, severityFilter, startDate, endDate]);

  useEffect(() => {
    let ws: WebSocket;
    let reconnectTimeout: NodeJS.Timeout;
    let reconnectAttempts = 0;
    let isComponentMounted = true;

    const connect = () => {
      if (!isComponentMounted) return;
      
      try {
        const protocol = window.location.protocol === 'https:' ? 'wss' : 'ws';
        ws = new WebSocket(`${protocol}://${window.location.host}`);
        
        ws.onopen = () => {
          reconnectAttempts = 0;
        };

        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            if (data.type === 'NEW_SYSTEM_ERROR') {
              fetchLogsRef.current();
              fetchAnalyticsRef.current();
            }
          } catch (e) {
            // Ignore parse errors
          }
        };

        ws.onclose = () => {
          if (isComponentMounted) {
            const delay = Math.min(5000 * Math.pow(2, reconnectAttempts), 30000);
            reconnectTimeout = setTimeout(connect, delay);
            reconnectAttempts++;
          }
        };

        ws.onerror = () => {
          // Error handled by onclose
        };
      } catch (e) {
        console.error("Failed to initiate WebSocket:", e);
      }
    };

    connect();

    return () => {
      isComponentMounted = false;
      clearTimeout(reconnectTimeout);
      if (ws) {
        ws.onclose = null; // Prevent reconnect on unmount
        try {
          if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) {
            ws.close();
          }
        } catch (e) {
          // Ignore close errors
        }
      }
    };
  }, []); // Empty dependencies!

  const getSeverityColor = (severity?: string) => {
    switch (severity) {
      case 'warning': return 'text-yellow-600 bg-yellow-100';
      case 'info': return 'text-blue-600 bg-blue-100';
      default: return 'text-red-600 bg-red-100';
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-6" dir={i18n.language === 'ar' ? 'rtl' : 'ltr'}>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-slate-900">{t('systemErrorLogs.title')}</h1>
        <div className="flex gap-2">
          <button onClick={fetchLogs} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors">
            <RefreshCw size={20} className="text-slate-600" />
          </button>
          <button onClick={exportLogs} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors">
            <Download size={20} className="text-slate-600" />
          </button>
          <button onClick={clearLogs} className="p-2 bg-white border border-slate-200 rounded-full hover:bg-slate-100 transition-colors text-red-500">
            <Trash2 size={20} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6 bg-white border border-slate-200 p-4 rounded-lg shadow-sm">
        <input type="text" placeholder={t('systemErrorLogs.filterByModule')} value={moduleFilter} onChange={(e) => setModuleFilter(e.target.value)} className="p-2 border border-slate-300 rounded bg-transparent text-slate-900" />
        <input type="text" placeholder={t('systemErrorLogs.filterByUserId')} value={userIdFilter} onChange={(e) => setUserIdFilter(e.target.value)} className="p-2 border border-slate-300 rounded bg-transparent text-slate-900" />
        <select value={severityFilter} onChange={(e) => setSeverityFilter(e.target.value)} className="p-2 border border-slate-300 rounded bg-transparent text-slate-900">
          <option value="">{t('systemErrorLogs.allSeverities')}</option>
          <option value="error">{t('systemErrorLogs.error')}</option>
          <option value="warning">{t('systemErrorLogs.warning')}</option>
          <option value="info">{t('systemErrorLogs.info')}</option>
        </select>
        <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="p-2 border border-slate-300 rounded bg-transparent text-slate-900" />
        <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="p-2 border border-slate-300 rounded bg-transparent text-slate-900" />
      </div>
      
      <SystemErrorAnalytics data={analytics} />
      
      <div className="bg-white border border-slate-200 shadow-sm rounded-lg overflow-hidden">
        <table className="w-full border-collapse">
          <thead className="bg-slate-100">
            <tr>
              <th className="p-3 text-start text-slate-700 font-semibold">{t('common.time')}</th>
              <th className="p-3 text-start text-slate-700 font-semibold">{t('common.module')}</th>
              <th className="p-3 text-start text-slate-700 font-semibold">{t('systemErrorLogs.severity')}</th>
              <th className="p-3 text-start text-slate-700 font-semibold">{t('common.message')}</th>
              <th className="p-3 text-start"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {loading ? (
              <tr>
                <td colSpan={5} className="p-10 text-center text-slate-500 italic">
                  {t('loading')}
                </td>
              </tr>
            ) : logs.length === 0 ? (
              <tr>
                <td colSpan={5} className="p-10 text-center text-slate-500 italic">
                  {t('systemErrorLogs.noErrorsLogged')}
                </td>
              </tr>
            ) : (Array.isArray(logs) ? logs : []).map(log => (
              <React.Fragment key={log.id}>
                <tr className="hover:bg-slate-50 cursor-pointer transition-colors" onClick={() => toggleRow(log.id)}>
                  <td className="p-3 text-sm font-mono text-slate-800">{formatDate(log.timestamp)}</td>
                  <td className="p-3 font-semibold text-slate-900">{log.module}</td>
                  <td className="p-3">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getSeverityColor(log.severity)}`}>
                      {t(`systemErrorLogs.${log.severity || 'error'}`)}
                    </span>
                  </td>
                  <td className="p-3 text-red-600 font-medium">{log.message}</td>
                  <td className="p-3 text-slate-700">
                    {expandedRows.includes(log.id) ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                  </td>
                </tr>
                {expandedRows.includes(log.id) && (
                  <tr>
                    <td colSpan={5} className="p-4 bg-slate-50 text-sm font-mono text-slate-900 whitespace-pre-wrap">
                      <strong className="block mb-2 text-slate-950">{t('systemErrorLogs.stackTrace')}:</strong>
                      {log.stack}
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      <Pagination 
        currentPage={pagination.page}
        totalPages={pagination.totalPages}
        onPageChange={(page) => setPagination(prev => ({ ...prev, page }))}
        pageSize={pagination.pageSize}
        onPageSizeChange={(pageSize) => setPagination(prev => ({ ...prev, pageSize, page: 1 }))}
        totalItems={pagination.total}
      />
    </div>
  );
};

export default SystemErrorLogs;
