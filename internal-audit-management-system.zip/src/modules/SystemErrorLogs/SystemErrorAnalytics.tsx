import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { useTranslation } from 'react-i18next';
import ChartContainer from '../../components/ChartContainer';

interface AnalyticsData {
  severity: string;
  count: number;
  date: string;
}

interface Props {
  data: AnalyticsData[];
}

const SystemErrorAnalytics: React.FC<Props> = ({ data }) => {
  const { t } = useTranslation();

  const chartData = data.reduce((acc: any, curr) => {
    const existing = acc.find((item: any) => item.date === curr.date);
    if (existing) {
      existing[curr.severity] = curr.count;
    } else {
      acc.push({ date: curr.date, [curr.severity]: curr.count });
    }
    return acc;
  }, []);

  return (
    <div className="bg-white p-4 rounded-lg shadow mb-6 h-[300px] flex flex-col min-w-0">
      <h2 className="text-lg font-semibold mb-4">{t('systemErrorLogs.errorTrends')}</h2>
      {data.length > 0 ? (
        <div className="flex-1 min-h-0 w-full min-w-0">
          <ChartContainer debugName="SystemErrorAnalyticsChart" minHeight={200}>
            {(width, height) => (
              <BarChart width={width} height={height} data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="error" fill="#ef4444" name={t('systemErrorLogs.error')} />
                <Bar dataKey="warning" fill="#eab308" name={t('systemErrorLogs.warning')} />
                <Bar dataKey="info" fill="#3b82f6" name={t('systemErrorLogs.info')} />
              </BarChart>
            )}
          </ChartContainer>
        </div>
      ) : (
        <div className="flex items-center justify-center h-full text-slate-500 italic">
          {t('systemErrorLogs.noAnalyticsData')}
        </div>
      )}
    </div>
  );
};

export default SystemErrorAnalytics;
