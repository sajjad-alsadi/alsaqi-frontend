const fs = require('fs');
fs.rmSync('/tmp/audit_db_persistent', {recursive: true, force: true});
console.log('done');
