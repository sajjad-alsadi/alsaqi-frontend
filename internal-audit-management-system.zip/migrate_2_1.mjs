import { db, initDb } from './src/server/db/index.js';

async function migrate() {
  await initDb();
  
  // Phase 2.1
  console.log("Renaming audit_tasks to audit_task_procedures_legacy...");
  try {
    await db.prepare("ALTER TABLE audit_tasks RENAME TO audit_task_procedures_legacy").run();
  } catch(e) {
    console.log("Rename failed or already done:", e.message);
  }

  console.log("Creating new audit_tasks table...");
  await db.prepare(`
    CREATE TABLE IF NOT EXISTS audit_tasks (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      task_number VARCHAR(30) UNIQUE NOT NULL,
      title TEXT NOT NULL,
      plan_id UUID NOT NULL REFERENCES audit_plans(id),
      program_id UUID REFERENCES audit_programs(id),
      audit_type TEXT NOT NULL, 
      status TEXT NOT NULL DEFAULT 'draft',
      assigned_to UUID REFERENCES users(id),
      audited_unit_id UUID REFERENCES org_entities(id),
      planned_hours INTEGER,
      actual_hours INTEGER DEFAULT 0,
      period_from DATE,
      period_to DATE,
      due_date DATE,
      approved_by UUID REFERENCES users(id),
      approved_at TIMESTAMPTZ,
      created_by UUID REFERENCES users(id),
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      deleted_at TIMESTAMPTZ
    );
  `).run();
  
  console.log("Phase 2.1 completed");
}

migrate().catch(console.error);
