const { PGlite } = require('@electric-sql/pglite');
async function test() {
  const db = new PGlite('/tmp/audit_db_persistent');
  const res = await db.query('SELECT * FROM users');
  console.log(res.rows);
}
test().catch(console.error);
